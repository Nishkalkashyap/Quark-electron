(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports"], factory);
    }
})(function (require, exports) {
    /*---------------------------------------------------------------------------------------------
     *  Copyright (c) Microsoft Corporation. All rights reserved.
     *  Licensed under the MIT License. See License.txt in the project root for license information.
     *--------------------------------------------------------------------------------------------*/
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    var Promise = monaco.Promise;
    const STOP_WHEN_IDLE_FOR = 2 * 60 * 1000; // 2min
    class WorkerManager {
        constructor(defaults) {
            this._defaults = defaults;
            this._worker = null;
            this._idleCheckInterval = setInterval(() => this._checkIfIdle(), 30 * 1000);
            this._lastUsedTime = 0;
            this._configChangeListener = this._defaults.onDidChange(() => this._stopWorker());
        }
        _stopWorker() {
            if (this._worker) {
                this._worker.dispose();
                this._worker = null;
            }
            this._client = null;
        }
        dispose() {
            clearInterval(this._idleCheckInterval);
            this._configChangeListener.dispose();
            this._stopWorker();
        }
        _checkIfIdle() {
            if (!this._worker) {
                return;
            }
            let timePassedSinceLastUsed = Date.now() - this._lastUsedTime;
            if (timePassedSinceLastUsed > STOP_WHEN_IDLE_FOR) {
                this._stopWorker();
            }
        }
        _getClient() {
            this._lastUsedTime = Date.now();
            if (!this._client) {
                this._worker = monaco.editor.createWebWorker({
                    // module that exports the create() method and returns a `HTMLWorker` instance
                    moduleId: 'vs/language/vue/vueWorker',
                    // passed in to the create() method
                    createData: {
                        languageSettings: this._defaults.options,
                        languageId: this._defaults.languageId
                    },
                    label: this._defaults.languageId
                });
                this._client = this._worker.getProxy();
            }
            return this._client;
        }
        getLanguageServiceWorker(...resources) {
            let _client;
            return toShallowCancelPromise(this._getClient().then((client) => {
                _client = client;
            }).then(_ => {
                return this._worker.withSyncedResources(resources);
            }).then(_ => _client));
        }
    }
    exports.WorkerManager = WorkerManager;
    function toShallowCancelPromise(p) {
        let completeCallback;
        let errorCallback;
        let r = new Promise((c, e) => {
            completeCallback = c;
            errorCallback = e;
        }, () => { });
        p.then(completeCallback, errorCallback);
        return r;
    }
});
