(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "vscode-html-languageservice", "vscode-languageserver-types", "./modes/languageModes"], factory);
    }
})(function (require, exports) {
    /*---------------------------------------------------------------------------------------------
     *  Copyright (c) Microsoft Corporation. All rights reserved.
     *  Licensed under the MIT License. See License.txt in the project root for license information.
     *--------------------------------------------------------------------------------------------*/
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    var Promise = monaco.Promise;
    const htmlService = require("vscode-html-languageservice");
    const ls = require("vscode-languageserver-types");
    const languageModes_1 = require("./modes/languageModes");
    class VueWorker {
        constructor(ctx, createData) {
            this._ctx = ctx;
            this._languageSettings = createData.languageSettings;
            this._languageId = createData.languageId;
            this._languageService = htmlService.getLanguageService();
            this.languageModes = languageModes_1.getLanguageModes(this._ctx, { css: true, javascript: true });
        }
        doValidation(uri) {
            // not yet suported
            return Promise.as([]);
        }
        doComplete(uri, position) {
            let document = this._getTextDocument(uri);
            let mode = this.languageModes.getModeAtPosition(document, position);
            if (mode && mode.doComplete) {
                return Promise.as(mode.doComplete(document, position, { css: true, javascript: true }));
            }
            return Promise.as({ isIncomplete: true, items: [] });
        }
        format(uri, range, options) {
            let document = this._getTextDocument(uri);
            let textEdits = this._languageService.format(document, range, null); //TODO options.
            return Promise.as(textEdits);
        }
        findDocumentHighlights(uri, position) {
            let document = this._getTextDocument(uri);
            let mode = this.languageModes.getModeAtPosition(document, position);
            if (mode && mode.findDocumentHighlight) {
                return Promise.as(mode.findDocumentHighlight(document, position));
            }
            return Promise.as([]);
        }
        findDocumentLinks(uri) {
            let document = this._getTextDocument(uri);
            let links = this._languageService.findDocumentLinks(document, null);
            return Promise.as(links);
        }
        _getTextDocument(uri) {
            let models = this._ctx.getMirrorModels();
            for (let model of models) {
                if (model.uri.toString() === uri) {
                    return ls.TextDocument.create(uri, this._languageId, model.version, model.getValue());
                }
            }
            return null;
        }
    }
    exports.VueWorker = VueWorker;
    function create(ctx, createData) {
        return new VueWorker(ctx, createData);
    }
    exports.create = create;
});
