(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "../languageModelCache", "../template/parser/htmlParser", "../template/services/htmlCompletion", "../template/services/htmlHover", "../template/services/htmlHighlighting", "../template/services/htmlLinks", "../template/services/htmlSymbolsProvider", "../template/tagProviders/componentTags", "../template/tagProviders/index"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const languageModelCache_1 = require("../languageModelCache");
    const htmlParser_1 = require("../template/parser/htmlParser");
    const htmlCompletion_1 = require("../template/services/htmlCompletion");
    const htmlHover_1 = require("../template/services/htmlHover");
    const htmlHighlighting_1 = require("../template/services/htmlHighlighting");
    const htmlLinks_1 = require("../template/services/htmlLinks");
    const htmlSymbolsProvider_1 = require("../template/services/htmlSymbolsProvider");
    const componentTags_1 = require("../template/tagProviders/componentTags");
    const index_1 = require("../template/tagProviders/index");
    function getVueHTMLMode(documentRegions, _ctx, scriptMode) {
        let settings = {};
        let completionOption = { html5: true, vue: true, router: true };
        //   let completionOption = getDefaultSetting(null); //TODO
        let basicTagProviders = index_1.getBasicTagProviders(completionOption);
        const embeddedDocuments = languageModelCache_1.getLanguageModelCache(10, 60, document => documentRegions.get(document).getEmbeddedDocument('vue-html'));
        const vueDocuments = languageModelCache_1.getLanguageModelCache(10, 60, document => htmlParser_1.parseHTMLDocument(document));
        //   const lintEngine = createLintEngine();
        return {
            getId() {
                return 'vue-html';
            },
            configure(options) {
                settings = options && options.html;
                completionOption = settings && settings.suggest || index_1.getDefaultSetting(null);
                basicTagProviders = index_1.getBasicTagProviders(completionOption);
            },
            doValidation(document) {
                const embedded = embeddedDocuments.get(document);
                return null;
                //   return doValidation(embedded, lintEngine);
            },
            doComplete(document, position) {
                const embedded = embeddedDocuments.get(document);
                const components = scriptMode.findComponents(document);
                const tagProviders = basicTagProviders.concat(componentTags_1.getComponentTags(components));
                return htmlCompletion_1.doComplete(embedded, position, vueDocuments.get(embedded), tagProviders);
            },
            doHover(document, position) {
                const embedded = embeddedDocuments.get(document);
                const components = scriptMode.findComponents(document);
                const tagProviders = basicTagProviders.concat(componentTags_1.getComponentTags(components));
                return htmlHover_1.doHover(embedded, position, vueDocuments.get(embedded), tagProviders);
            },
            findDocumentHighlight(document, position) {
                return htmlHighlighting_1.findDocumentHighlights(document, position, vueDocuments.get(document));
            },
            findDocumentLinks(document, documentContext) {
                return htmlLinks_1.findDocumentLinks(document, documentContext);
            },
            findDocumentSymbols(document) {
                return htmlSymbolsProvider_1.findDocumentSymbols(document, vueDocuments.get(document));
            },
            format(document, range, formattingOptions) {
                //   return htmlFormat(document, range, formattingOptions);
                return null;
            },
            onDocumentRemoved(document) {
                vueDocuments.onDocumentRemoved(document);
            },
            dispose() {
                vueDocuments.dispose();
            }
        };
    }
    exports.getVueHTMLMode = getVueHTMLMode;
});
