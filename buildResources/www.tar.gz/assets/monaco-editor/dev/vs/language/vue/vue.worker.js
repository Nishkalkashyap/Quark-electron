(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "monaco-editor/esm/vs/editor/editor.worker", "./vueWorker"], factory);
    }
})(function (require, exports) {
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    const worker = require("monaco-editor/esm/vs/editor/editor.worker");
    const vueWorker_1 = require("./vueWorker");
    self.onmessage = function () {
        // ignore the first message
        worker.initialize(function (ctx, createData) {
            return new vueWorker_1.VueWorker(ctx, createData);
        });
    };
});
