(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./common", "./element-helper-json/element-tags", "./element-helper-json/element-attributes"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const common_1 = require("./common");
    const element_tags_1 = require("./element-helper-json/element-tags");
    const element_attributes_1 = require("./element-helper-json/element-attributes");
    function getElementTagProvider() {
        return {
            getId: () => 'element',
            priority: common_1.Priority.Library,
            collectTags(collector) {
                for (const tagName in element_tags_1.tags) {
                    collector(tagName, element_tags_1.tags[tagName].description || '');
                }
            },
            collectAttributes(tag, collector) {
                if (!element_tags_1.tags[tag]) {
                    return;
                }
                const attrs = element_tags_1.tags[tag].attributes;
                if (!attrs) {
                    return;
                }
                for (const attr of attrs) {
                    const detail = findAttributeDetail(tag, attr);
                    collector(attr, undefined, detail && detail.description || '');
                }
            },
            collectValues(tag, attr, collector) {
                if (!element_tags_1.tags[tag]) {
                    return;
                }
                const attrs = element_tags_1.tags[tag].attributes;
                if (!attrs || attrs.indexOf(attr) < 0) {
                    return;
                }
                const detail = findAttributeDetail(tag, attr);
                if (!detail || !detail.options) {
                    return;
                }
                for (const option of detail.options) {
                    collector(option);
                }
            }
        };
    }
    exports.getElementTagProvider = getElementTagProvider;
    function findAttributeDetail(tag, attr) {
        return element_attributes_1.attributes[attr] || element_attributes_1.attributes[tag + '/' + attr];
    }
});
