(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "../lib/typescriptServices"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    // import * as ts from 'typescript';
    const ts = require("../lib/typescriptServices");
    function findComponents(service, fileFsPath) {
        const program = service.getProgram();
        const sourceFile = program.getSourceFile(fileFsPath);
        const exportStmt = sourceFile.statements.filter(st => st.kind === ts.SyntaxKind.ExportAssignment);
        if (exportStmt.length === 0) {
            return [];
        }
        // vls will create synthetic __vueEditorBridge({ ... })
        const exportCall = exportStmt[0].expression;
        if (exportCall.kind !== ts.SyntaxKind.CallExpression) {
            return [];
        }
        const comp = exportCall.arguments[0];
        const checker = program.getTypeChecker();
        const compType = checker.getTypeAtLocation(comp);
        const childComps = getPropertyTypeOfType(compType, 'components', checker);
        if (!childComps) {
            return [];
        }
        return checker.getPropertiesOfType(childComps).map(s => getCompInfo(s, checker));
    }
    exports.findComponents = findComponents;
    function getCompInfo(symbol, checker) {
        const compType = getSymbolType(symbol, checker);
        const info = {
            name: symbol.name
        };
        if (!compType) {
            return info;
        }
        const arrayProps = getArrayProps(compType, checker);
        if (arrayProps) {
            info.props = arrayProps;
            return info;
        }
        const props = getPropertyTypeOfType(compType, 'props', checker);
        if (!props) {
            return info;
        }
        info.props = checker.getPropertiesOfType(props).map(s => {
            return {
                name: s.name,
                doc: getPropTypeDeclaration(s, checker)
            };
        });
        return info;
    }
    function getPropTypeDeclaration(prop, checker) {
        if (!prop.valueDeclaration) {
            return '';
        }
        const declaration = prop.valueDeclaration.getChildAt(2);
        if (!declaration) {
            return '';
        }
        if (declaration.kind === ts.SyntaxKind.ObjectLiteralExpression) {
            const text = [];
            declaration.forEachChild(n => {
                text.push(n.getText());
            });
            return text.join('\n');
        }
        return declaration.getText();
    }
    function getArrayProps(compType, checker) {
        const propSymbol = checker.getPropertyOfType(compType, 'props');
        if (!propSymbol || !propSymbol.valueDeclaration) {
            return undefined;
        }
        const propDef = propSymbol.valueDeclaration.getChildAt(2);
        if (!propDef || propDef.kind !== ts.SyntaxKind.ArrayLiteralExpression) {
            return undefined;
        }
        const propArray = propDef;
        return propArray.elements
            .filter(e => e.kind === ts.SyntaxKind.StringLiteral)
            .map((e) => ({ name: e.text }));
    }
    function getPropertyTypeOfType(tpe, property, checker) {
        const propSymbol = checker.getPropertyOfType(tpe, property);
        return getSymbolType(propSymbol, checker);
    }
    function getSymbolType(symbol, checker) {
        if (!symbol || !symbol.valueDeclaration) {
            return undefined;
        }
        return checker.getTypeOfSymbolAtLocation(symbol, symbol.valueDeclaration);
    }
});
