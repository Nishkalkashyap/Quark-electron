(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./vueLanguage"], factory);
    }
})(function (require, exports) {
    /*---------------------------------------------------------------------------------------------
     *  Copyright (c) Microsoft Corporation. All rights reserved.
     *  Licensed under the MIT License. See License.txt in the project root for license information.
     *--------------------------------------------------------------------------------------------*/
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    const vueLanguage_1 = require("./vueLanguage");
    var Emitter = monaco.Emitter;
    // --- vue configuration and defaults ---------
    class LanguageServiceDefaultsImpl {
        constructor(languageId, options) {
            this._onDidChange = new Emitter();
            this._languageId = languageId;
            this.setOptions(options);
        }
        get onDidChange() {
            return this._onDidChange.event;
        }
        get languageId() {
            return this._languageId;
        }
        get options() {
            return this._options;
        }
        setOptions(options) {
            this._options = options || Object.create(null);
            this._onDidChange.fire(this);
        }
    }
    exports.LanguageServiceDefaultsImpl = LanguageServiceDefaultsImpl;
    const vueOptionsDefault = {
        suggest: { html5: true, angular1: true, ionic: true }
    };
    const vueLanguageId = 'vue';
    const vueDefaults = new LanguageServiceDefaultsImpl(vueLanguageId, vueOptionsDefault);
    // Export API
    function createAPI() {
        return {
            vueDefaults: vueDefaults
        };
    }
    monaco.languages.vue = createAPI();
    // --- Registration to monaco editor ---
    function withMode(callback) {
        require(['vs/language/vue/vueMode'], callback);
    }
    monaco.languages.register({
        id: 'vue',
        extensions: ['.vue'],
        aliases: ['Vue', 'vuejs']
    });
    monaco.languages.setMonarchTokensProvider('vue', vueLanguage_1.language);
    monaco.languages.setLanguageConfiguration('vue', vueLanguage_1.conf);
    monaco.languages.onLanguage(vueLanguageId, () => {
        withMode(mode => mode.setupMode(vueDefaults));
    });
});
