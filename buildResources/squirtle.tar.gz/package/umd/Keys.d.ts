export declare const Keys: {
    TabsViewProvider: string;
    SideViewProvider: string;
    BottomViewProvider: string;
    OverlayViewProvider: string;
    ContextMenuService: string;
    Snackbars: string;
    SnackbarsSubject: string;
    IconMir: string;
    IconDom: string;
    Settings: string;
    QuickViewElement: string;
    KeyBindingStoreRunTime: string;
    KeyBindingStoreDevTime: string;
    KeyBindingSubject: string;
    BrowserFileSystem: string;
    Mousetrap: string;
    ThemeChangeSubject: string;
};
