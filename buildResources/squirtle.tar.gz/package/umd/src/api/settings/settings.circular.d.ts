export declare enum SettingScope {
    local = "local",
    global = "global"
}
export declare type son = string | number;
export declare enum SettingType {
    INPUT = "input",
    TEXTAREA = "textarea",
    SELECT = "select",
    CHECKBOX = "checkbox",
    STRING_ARRAY = "stringArray",
    BUTTON = "button",
    OBJECT = "object"
}
export declare type Iobject = {
    id: son;
    label: son;
    value: son;
};
export interface IObject {
    default: Iobject[];
    value?: Iobject[];
}
export interface IInput {
    default: son;
    value?: son;
}
export interface ITextArea {
    default: son;
    value?: son;
}
export interface ISelect {
    default: son;
    value?: son;
    options: son[];
    optionsViewValue?: son[];
}
export interface ICheckbox {
    default: boolean;
    value?: boolean;
}
export interface IInputTextArray {
    default: son[];
    value?: son[];
}
export interface IButton {
    default: son;
    handler: () => void;
}
export interface Item {
    id: string;
    name: string;
    description: string;
    type: SettingType;
}
export interface Item {
    input?: IInput;
    textarea?: ITextArea;
    select?: ISelect;
    checkbox?: ICheckbox;
    stringArray?: IInputTextArray;
    button?: IButton;
    object?: IObject;
}
export interface Group {
    id: string;
    name: string;
    items: Item[];
}
export interface Namespace {
    id: string;
    name: string;
    groups: Group[];
}
