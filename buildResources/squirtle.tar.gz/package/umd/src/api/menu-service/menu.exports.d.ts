import { MenuItem, Menu } from './menu.service';
export { MenuItem, ContextMenuTrigger } from './menu.service';
export interface MenuRef {
    items: MenuItem[];
    dispose: () => void;
    update: (menu: MenuItem[]) => void;
}
export interface ContextMenuRef {
    items: MenuItem[];
    dispose: () => void;
    update: (menu: MenuItem[]) => void;
    show: (x: number, y: number) => void;
}
export declare namespace menu {
    function createMenu(_menu: Menu): MenuRef;
    function getMenuById(id: string): Menu;
    function getContextMenuById(id: string): Menu;
}
