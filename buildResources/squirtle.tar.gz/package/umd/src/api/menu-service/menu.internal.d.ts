import { ContextMenuService, MenuService } from "./menu.service";
export { Menu as __Menu, ContextMenuTrigger } from './menu.service';
export declare const Menu: MenuService;
export declare const contextMenu: ContextMenuService;
