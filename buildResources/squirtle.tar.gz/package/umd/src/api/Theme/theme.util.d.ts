import { AppTheme } from './theme.exports';
export declare function setAppTheme(theme: AppTheme): void;
