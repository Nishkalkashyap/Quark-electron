import { FSWatcher } from 'chokidar';
export { WatchOptions, WatchedPaths, AwaitWriteFinishOptions } from 'chokidar';
export declare type WatchEvents = 'add' | 'addDir' | 'change' | 'unlink' | 'unlinkDir' | 'ready' | 'raw' | 'error' | 'all';
export interface Watcher extends FSWatcher {
}
