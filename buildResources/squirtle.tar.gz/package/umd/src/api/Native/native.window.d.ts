import * as _native from './native.service';
export import native = _native;
