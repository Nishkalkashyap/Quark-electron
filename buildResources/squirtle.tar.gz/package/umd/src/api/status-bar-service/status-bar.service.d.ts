import { StatusBarItem } from './status-bar.exports';
import { IDisposable } from '../../../exports';
export declare class StatusBarService {
    private _items;
    readonly items: StatusBarItem[];
    registerItem(item: StatusBarItem): IDisposable;
    private _removeItem;
}
