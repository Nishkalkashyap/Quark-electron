import { IDisposable } from './../../../exports';
declare class OutputController {
    private _channels;
    readonly channels: InternalOutputChannel[];
    private _currentChannelId;
    readonly currentChannelId: string;
    private _scrollIsLocked;
    readonly scrollIsLocked: boolean;
    toggleScrollLock(): void;
    getCurrentChannel(): InternalOutputChannel;
    clearCurrentChannel(): void;
    private _valueChangeSubject;
    private _channelChangeSubject;
    private _channelAddSubject;
    private _channelRemoveSubject;
    onDidChangeChannel(func: (channelId?: string) => void): IDisposable;
    onDidChangeValue(func: (channelId?: string) => void): IDisposable;
    onDidAddChannel(func: (channelId?: string) => void): IDisposable;
    onDidRemoveChannel(func: (channelId?: string) => void): IDisposable;
    addChannel(channel: InternalOutputChannel): void;
    removeChannel(channelId: string): void;
    makeCurrentChannel(channelId: string): void;
    triggerValueChangeUpdate(channel: string): void;
}
export declare const outputController: OutputController;
export declare class InternalOutputChannel {
    readonly name: string;
    private _value;
    readonly value: string;
    private _isHidden;
    readonly isHidden: boolean;
    private _id;
    readonly id: string;
    constructor(name: string);
    append(value: string | number | object): void;
    appendLine(value: string | number | object): void;
    clear(): void;
    show(): void;
    hide(): void;
    dispose(): void;
}
export {};
