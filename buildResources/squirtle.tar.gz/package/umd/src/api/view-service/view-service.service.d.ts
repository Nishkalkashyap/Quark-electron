import { IDisposable } from './../../../exports';
import { views } from './view-service.internals';
declare abstract class ViewService {
    private _key;
    private _views;
    protected _currentView: views.ViewProvider;
    getCurrentView(): views.ViewProvider;
    getAllViews(): views.ViewProvider[];
    private _isNavbarVisible;
    isNavbarVisible(): boolean;
    toggleNavbar(): void;
    hideNavbar(): void;
    showNavbar(): void;
    selectNextView(): views.ViewProvider;
    selectPreviousView(): views.ViewProvider;
    protected readonly _viewContainer: HTMLDivElement;
    constructor(_key: string);
    triggerUpdate(): void;
    registerView(view: views.ViewProvider): IDisposable;
    removeView(view: views.ViewProvider): void;
    protected _removeViewHandle(view: views.ViewProvider, index: number): Promise<void>;
    getViewById(id: string): views.ViewProvider | undefined;
    setView(_view: views.ViewProvider): Promise<void>;
}
declare abstract class VisibilityService extends ViewService {
    private _isVisible;
    isVisible(): boolean;
    toggle(): void;
    hide(): void;
    show(): void;
}
export declare class SideViewService extends VisibilityService {
}
export declare class BottomViewService extends VisibilityService {
}
export declare class TabsViewService extends ViewService {
}
export declare class OverlayViewService extends ViewService {
    private _overlayProviderContainerTag;
    constructor(_key: string, _overlayProviderContainerTag: string);
    private _minimizedViews;
    readonly minimizedViews: views.ViewProvider[];
    setView(_view: views.ViewProvider): Promise<void>;
    removeView(view: views.ViewProvider): void;
    private _maximizeView;
    private _minimizeView;
    hide(): void;
}
export {};
