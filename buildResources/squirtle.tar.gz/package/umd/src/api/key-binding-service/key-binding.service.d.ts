import { IDisposable } from '../../../exports';
export interface ICondition {
    id: string;
    handle: () => boolean;
    thisArgs?: any;
}
export interface IKeyBinding {
    keybindings: string | string[];
    command: string;
    when?: string;
}
export interface IKeyBindingRegister {
    addKeyBinding: (keybindings: IKeyBinding['keybindings'], when?: string) => IKeyBindingRegister;
}
export declare enum KeyCode {
    SHIFT = "shift",
    CTRL = "ctrl",
    ALT = "alt",
    META = "meta",
    BACKSPACE = "backspace",
    TAB = "tab",
    ENTER = "enter",
    RETURN = "return",
    CAPSLOCK = "capslock",
    ESC = "esc",
    ESCAPE = "escape",
    SPACE = "space",
    PAGEUP = "pageup",
    PAGEDOWN = "pagedown",
    END = "end",
    HOME = "home",
    LEFT = "left",
    UP = "up",
    RIGHT = "right",
    DOWN = "down",
    INS = "ins",
    DEL = "del",
    PLUS = "plus"
}
export declare class KeyBindingService {
    private _subjectKey;
    private _devTimeStoreKey;
    private _runTimeStoreKey;
    private _conditions;
    readonly conditions: ICondition[];
    currentMode: 'runTimeBindings' | 'devTimeBindings';
    private _devTimeBindings;
    readonly devTimeBindings: IKeyBinding[];
    private _devTimeStore;
    private readonly _event;
    constructor(_subjectKey: string, _devTimeStoreKey: string, _runTimeStoreKey: string);
    initialize(): void;
    addCondition(condition: ICondition): IDisposable;
    getBindingForCommand(command: string): IKeyBinding['keybindings'] | undefined;
    addDevTimeBinding(binding: IKeyBinding): IKeyBindingRegister;
    updateBinding(old: IKeyBinding['keybindings'], newBinding: IKeyBinding): void;
    getRegister(id: string): IKeyBindingRegister;
    private _addBinding;
    private _runWithCondition;
    keyBindingInnerHTML(item: IKeyBinding['keybindings']): string;
}
export declare const keyBinding: KeyBindingService;
