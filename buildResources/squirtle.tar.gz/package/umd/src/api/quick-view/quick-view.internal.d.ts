import { QuickInputButton, InputBox, IQuickPick } from "./quick-view.exports";
import { Subject } from 'rxjs';
export interface QuickViewElementMethods {
    quickView: IQuickPick | InputBox;
    quickViewProxy: QuickViewProxy;
}
export interface QuickViewProxy {
    selectedButton?: QuickInputButton;
    triggerUpdate: Subject<null>;
}
export declare type QuickViewElement = HTMLElement & QuickViewElementMethods;
