export interface Icon {
    name: string;
    path: string;
}
export declare class IconService {
    private _keyMir;
    private _keyDom;
    private readonly mir;
    private readonly dom;
    constructor(_keyMir: string, _keyDom: string);
    registerIcon(icon: Icon): void;
    registerIcons(icons: Icon[]): void;
    registerIconInNamespace(icon: Icon, namespace: string): void;
    registerIconsInNamespace(icons: Icon[], namespace: string): void;
}
