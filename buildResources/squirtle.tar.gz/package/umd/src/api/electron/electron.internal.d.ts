export declare enum IpcEvents {
    ADD_DEV_MODE_WINDOW = "ADD_DEV_MODE_WINDOW",
    ADD_RUN_MODE_WINDOW = "ADD_RUN_MODE_WINDOW",
    HIDE_BUILD_LOADING = "HIDE_BUILD_LOADING"
}
export declare type IBrowserWindow = Electron.BrowserWindow & WindowData;
export interface WindowData {
    data: {
        project: string;
        showLandingPage: boolean;
        isDevMode: boolean;
        appPath: string;
        home: string;
    };
}
export interface AutoUpdateInterface {
    releaseChannel: 'stable' | 'insiders';
    disableAutoUpdates: boolean;
}
export declare const autoUpdatesFilePath: any;
export declare namespace electron {
    const module: typeof Electron;
    const mainProcess: NodeJS.Process;
    const fs: typeof import('fs-extra');
    const path: typeof import('path');
    const browserWindow: IBrowserWindow;
}
