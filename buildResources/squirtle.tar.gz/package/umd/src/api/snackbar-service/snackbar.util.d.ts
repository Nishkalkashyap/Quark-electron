import { SnackbarItem } from './snackbar.service';
export declare function createSnackbar(message: string, type?: 'danger' | 'success' | 'warning' | 'info', duration?: number): SnackbarItem;
