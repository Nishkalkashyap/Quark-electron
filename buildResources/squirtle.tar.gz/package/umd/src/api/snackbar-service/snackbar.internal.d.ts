import { SnackbarItem, snackbar } from './snackbar.service';
export { snackbar };
export declare class ISnackbarItem extends SnackbarItem {
}
