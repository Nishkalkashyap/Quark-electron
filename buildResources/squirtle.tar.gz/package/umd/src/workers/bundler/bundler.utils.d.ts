export declare function makeFilesystemFromObject(obj: object, fs: typeof import('fs')): void;
export declare function getMemoryFs(): typeof import('fs');
