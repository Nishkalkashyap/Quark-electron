export declare enum Messages {
    bundle = 0,
    parentBrowserWindow = 1,
    webpackConfig = 2
}
export declare enum WORKER_TO_WINDOW {
    ERROR = "a",
    SUCCESS = "b"
}
export interface MessageData<T = any> {
    message: Messages | WORKER_TO_WINDOW;
    data: T;
}
