import regexTokeniser from './tokenizer.util';
export { regexTokeniser };
export declare function add(a: number, b: number): number;
