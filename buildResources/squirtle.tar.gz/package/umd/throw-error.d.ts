export declare function throwError(input: any): void;
