import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { storage } from '../storage/storage.exports';
import { throwError } from './../../../throw-error';

export interface Icon {
    name: string;
    path: string;
}

export class IconService {

    private get mir(): MatIconRegistry { return storage.inMemory.get(this._keyMir); };
    private get dom(): DomSanitizer { return storage.inMemory.get(this._keyDom); }

    constructor(private _keyMir: string, private _keyDom: string) { }

    public registerIcon(icon: Icon): void {
        this.mir.addSvgIcon(
            icon.name,
            this.dom.bypassSecurityTrustResourceUrl(icon.path)
        );
    }

    public registerIcons(icons: Icon[]): void {
        if (!(Array.isArray(icons)))
            throwError('Input must be an array');

        icons.map((val) => {
            this.registerIcon(val);
        });
    }

    public registerIconInNamespace(icon: Icon, namespace: string): void {
        if (typeof namespace != 'string')
            throwError('Namespace must be of type string');

        this.mir.addSvgIconInNamespace(
            namespace,
            icon.name,
            this.dom.bypassSecurityTrustResourceUrl(icon.path)
        );
    }


    public registerIconsInNamespace(icons: Icon[], namespace: string): void {
        if (!(Array.isArray(icons)))
            throwError('Input must be an array');

        if (typeof namespace != 'string')
            throwError('Namespace must be of type string');

        icons.map((val) => {
            this.registerIconInNamespace(val, namespace);
        });
    }
}