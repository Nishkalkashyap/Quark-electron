import { ISnackbarItem } from './snackbar.internal';
import { SnackbarItem } from './snackbar.service';

export function createSnackbar(message: string, type?: 'danger' | 'success' | 'warning' | 'info', duration?: number): SnackbarItem {
    return new ISnackbarItem(message, type, duration);
}