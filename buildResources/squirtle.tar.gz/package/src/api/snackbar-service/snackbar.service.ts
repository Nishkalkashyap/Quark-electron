import { BehaviorSubject } from 'rxjs';
import { storage } from '../storage/storage.exports';
import { Keys } from './../../../Keys';
import { throwError } from './../../../throw-error';


export interface ISnackbarButton {
    label: string;
    handle: () => void;
    icon?: string;
}


export abstract class SnackbarItem {

    public show(): void { snackbar.addSnackbar(this); }
    public dispose(): void { snackbar.removeSnackbar(this.id); }

    private _id = `snackbar` + Date.now() + Math.floor(Math.random() * 100);
    get id() { return this._id };

    public buttons: ISnackbarButton[];
    public element: HTMLElement;

    constructor(
        public message: string,
        public type?: 'danger' | 'success' | 'warning' | 'info',
        public duration?: number,
    ) { }
}

export class SnackbarService {

    private get _snackbars(): SnackbarItem[] { return storage.inMemory.get(this._snackbarKey); }
    private get _subject(): BehaviorSubject<string> {
        return storage.inMemory.get(this._subjectKey);
    }

    constructor(private _snackbarKey: string, private _subjectKey: string) { }

    public removeSnackbar(id: string): void {
        if (!(typeof id == 'string'))
            throwError('Id must be of type string');

        let snackbarIndex = this._snackbars.findIndex((val) => { return val.id == id });
        if (snackbarIndex == -1)
            throwError('Snackbar with the provided id does not exists');

        let removedSnackbar = this._snackbars.splice(snackbarIndex - 1, 1);
        this._subject.next(removedSnackbar[0].id);
    }

    public addSnackbar(_snackbar: SnackbarItem): void {
        if (!(_snackbar && _snackbar instanceof SnackbarItem))
            throwError('The provided object is not of class IMessageSnackbar');

        const snackbar = _snackbar;
        this._snackbars.push(snackbar);
        this._subject.next(snackbar.id);
    }
}

export const snackbar = new SnackbarService(Keys.Snackbars, Keys.SnackbarsSubject);