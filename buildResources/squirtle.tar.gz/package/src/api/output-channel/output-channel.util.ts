import { InternalOutputChannel } from './output-channel.service';
import { OutputChannel } from './output-channel.exports';

export function createOutputChannel(name: string): OutputChannel {
    const channel = new InternalOutputChannel(name);
    return {
        append: channel.append.bind(channel),
        appendLine: channel.appendLine.bind(channel),
        clear: channel.clear.bind(channel),
        dispose: channel.dispose.bind(channel),
        hide: channel.hide.bind(channel),
        show: channel.show.bind(channel),
        name: channel.name,
    }
}