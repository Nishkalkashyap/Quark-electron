import { throwError } from './../../../throw-error';
import { Subject } from 'rxjs';
import { IDisposable } from './../../../exports';

class OutputController {
    private _channels: InternalOutputChannel[] = [];
    public get channels(): InternalOutputChannel[] {
        return this._channels;
    }
    private _currentChannelId: string;
    public get currentChannelId(): string {
        return this._currentChannelId || this._channels[0].id;
    }

    private _scrollIsLocked = true;
    public get scrollIsLocked(): boolean {
        return this._scrollIsLocked;
    }
    public toggleScrollLock() {
        this._scrollIsLocked = !this._scrollIsLocked;
    }


    public getCurrentChannel() {
        return this._channels.find((val) => { return val.id == this._currentChannelId }) || this._channels[0];
    }

    public clearCurrentChannel() {
        const currentChannel = this.getCurrentChannel();
        if (currentChannel) {
            currentChannel.clear();
        }
    }

    private _valueChangeSubject: Subject<string> = new Subject();
    private _channelChangeSubject: Subject<string> = new Subject();
    private _channelAddSubject: Subject<string> = new Subject();
    private _channelRemoveSubject: Subject<string> = new Subject();

    public onDidChangeChannel(func: (channelId?: string) => void): IDisposable {
        const subscription = this._channelChangeSubject.subscribe(func);
        return {
            dispose: () => {
                subscription.unsubscribe();
            }
        }
    }

    public onDidChangeValue(func: (channelId?: string) => void): IDisposable {
        const subscription = this._valueChangeSubject.subscribe(func);
        return {
            dispose: () => {
                subscription.unsubscribe();
            }
        }
    }

    public onDidAddChannel(func: (channelId?: string) => void): IDisposable {
        const subscription = this._channelAddSubject.subscribe(func);
        return {
            dispose: () => {
                subscription.unsubscribe();
            }
        }
    }

    public onDidRemoveChannel(func: (channelId?: string) => void): IDisposable {
        const subscription = this._channelRemoveSubject.subscribe(func);
        return {
            dispose: () => {
                subscription.unsubscribe();
            }
        }
    }

    public addChannel(channel: InternalOutputChannel): void {
        this._channels.push(channel);
        this._channelAddSubject.next(channel.id);
    }

    public removeChannel(channelId: string): void {
        const index = this._channels.findIndex((val) => {
            return val.id == channelId;
        });

        if (index !== -1) {
            this._channels.splice(index, 1);
        }

        this._channelRemoveSubject.next(channelId);
        this._currentChannelId == channelId ? this._currentChannelId = this._channels.reverse()[0].id : null;
        this._channelChangeSubject.next(this._currentChannelId);
    }

    public makeCurrentChannel(channelId: string) {
        if (this._currentChannelId != channelId) {
            this._currentChannelId = channelId;
            this._channelChangeSubject.next(channelId);
        }
    }

    public triggerValueChangeUpdate(channel: string): void {
        this._valueChangeSubject.next(channel);
    }
}

export const outputController = new OutputController();

export class InternalOutputChannel {
    private _value: string = '';
    public get value(): string {
        return this._value;
    }

    private _isHidden: boolean = false;
    public get isHidden(): boolean {
        return this._isHidden;
    }

    private _id: string = (Date.now() + Math.random()).toString();
    public get id(): string { return this._id; }

    constructor(public readonly name: string) {
        outputController.addChannel(this);
    }

    public append(value: string | number | object): void {
        let printValue: string;
        if ((typeof value == 'string' || typeof value == 'number')) {
            printValue = value.toString();
        } else {
            try {
                printValue = JSON.stringify(value);
            } catch (err) {
                throwError(err);
            }
        }

        this._value += (printValue || ' ');
        outputController.triggerValueChangeUpdate(this.id);
    }

    public appendLine(value: string | number | object): void {
        let printValue: string;
        if ((typeof value == 'string' || typeof value == 'number')) {
            printValue = value.toString();
        } else {
            try {
                printValue = JSON.stringify(value);
            } catch (err) {
                throwError(err);
            }
        }

        this._value += '\n';
        this._value += (printValue || ' ');
        outputController.triggerValueChangeUpdate(this.id);
    }

    public clear(): void {
        this._value = '';
        outputController.triggerValueChangeUpdate(this.id);
    }

    public show(): void {
        this._isHidden = false;
        outputController.makeCurrentChannel(this.id);
    }

    public hide(): void {
        this._isHidden = true;
    }

    public dispose(): void {
        outputController.removeChannel(this.id);
    }
}