import { throwError } from './../../../throw-error';
import { storage } from '../storage/storage.exports';

export const handles: Function[] = [];

export function runOnQuitHandles(): Promise<boolean> {
    // return new Promise((resolve) => {
    // let results: boolean[] = [];
    // handles.map(async (func, index) => {
    //     try {
    //         let result = await func();
    //         results.push(result);
    //     } catch (err) {
    //         throwError(err);
    //     } finally {
    //         if (index == handles.length - 1) {
    //             let finalResult: boolean;
    //             results.map((_result) => {
    //                 finalResult = finalResult || _result;
    //             });
    //             resolve(finalResult);
    //         }
    //     }
    // });

    // });

    return new Promise((resolve) => {
        const promise = Promise.all(handles.map((func) => {
            return new Promise<boolean>(async (res) => {
                try {
                    const result = await func();
                    res(result);
                } catch (err) {
                    throwError(err);
                    res(false);
                }
            });
        }));

        promise.then((val) => {
            let finalResult: boolean;
            val.map((result) => {
                finalResult = finalResult || result;
            });
            storage.global.forceUpdate();
            storage.local.forceUpdate();
            resolve(finalResult);
        });
    });
}