import { IQuickPick, InputBox } from './quick-view.exports';

export function createQuickView(): IQuickPick {
    return new IQuickPick();
}

export function createInputBox(): InputBox {
    return new InputBox();
}