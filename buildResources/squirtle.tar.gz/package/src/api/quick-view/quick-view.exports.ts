import { QuickViewProxy, QuickViewElement } from './quick-view.internal';
import { Subject } from 'rxjs';
import { Keys } from './../../../Keys';
import { throwError } from './../../../throw-error';

export interface QuickInputButton {

    icon?: string;
    label: string;
    description?: string;

    detail?: string;
    endIcon?: string;
    endIconTooltip?: string;

    divider?: boolean;

    data?: any;
}

export class InputBox {
    private _id: string = (Math.random() + Date.now()).toString();
    public get id(): string { return this._id; }
    protected _quickViewProxy: QuickViewProxy = {
        triggerUpdate: new Subject()
    };

    private _isVisible: boolean = false;
    public get isVisible(): boolean { return this._isVisible; }
    public password: boolean = false;

    public ignoreFocusOut: boolean = false;
    public ignoreHide: boolean = false;
    public busy: boolean;

    public value: string = '';
    public placeholder: string = '';
    public panelClass: string;

    public onDidChangeValue: () => void;
    public onKeyUp: (e?: KeyboardEvent) => void;
    public onKeyDown: (e?: KeyboardEvent) => void;
    public onDidAccept: () => void;//enter handle

    public prompt: string;
    public validationMessage: string | undefined;

    public show(): void {
        document.querySelectorAll(Keys.QuickViewElement).forEach((el: QuickViewElement) => {
            el.id != this._id ? this._hideView(el) : null;
        });

        const exists = document.getElementById(this._id);
        if (exists) {
            exists.style.display = 'block';
        } else {
            const element = document.createElement(Keys.QuickViewElement) as QuickViewElement;
            element.id = this._id;
            element.style.display = 'block';
            element.quickView = this;
            element.quickViewProxy = this._quickViewProxy;
            document.body.appendChild(element);
        }

        this._isVisible = true;
        this._quickViewProxy.triggerUpdate.next();
    }

    private _hideView(el: QuickViewElement) {
        if (el && el.style.display == 'block') {
            el.style.display = 'none';
            this._isVisible = false;
            if (typeof el.quickView.onDidHide == 'function') {
                el.quickView.onDidHide();
            }
        }
    }

    public hide(): void {
        const element = document.getElementById(this._id) as QuickViewElement;
        this._hideView(element);
    }

    public dispose(): void {
        this._isVisible = false;
        const element = document.getElementById(this._id) as QuickViewElement;
        if (element) {
            element.remove();
        }
    }

    public onDidHide: () => void;
}

export class IQuickPick extends InputBox {
    public matchOnDescription: boolean = false;
    public matchOnDetail: boolean = false;
    public onDidTriggerButton: (button?: QuickInputButton) => void;//right arrow handle

    private _buttons: QuickInputButton[] = [];
    public get buttons(): QuickInputButton[] { return this._buttons; }
    public set buttons(input: QuickInputButton[]) {
        if (!Array.isArray(input)) {
            throwError('Must be array');
        }
        this._buttons = input;
        this._quickViewProxy.triggerUpdate.next();
    }

    public get selectedButton(): QuickInputButton {
        return this._quickViewProxy.selectedButton;
    }
}