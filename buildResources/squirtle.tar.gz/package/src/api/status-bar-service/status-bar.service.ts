import { StatusBarItem } from './status-bar.exports';
import { IDisposable } from '../../../exports';
import { throwError } from './../../../throw-error';

export class StatusBarService {

    private _items: StatusBarItem[] = [];
    public get items(): StatusBarItem[] {
        return this._items;
    }

    public registerItem(item: StatusBarItem): IDisposable {
        if (!(item instanceof StatusBarItem))
            throwError('Item must be of type StatusBarItem');

        this._items.push(item);
        const disposable: IDisposable = {
            dispose: () => {
                this._removeItem(item);
            }
        }

        return disposable;
    }

    private _removeItem(id: StatusBarItem): StatusBarItem | undefined {
        let findIndex = this._items.findIndex((val) => { return val == id });
        if (findIndex == -1) {
            throwError('Could not find Statusbar with the provided id');
            return;
        }

        return this._items.splice(findIndex, 1)[0];
    }
}