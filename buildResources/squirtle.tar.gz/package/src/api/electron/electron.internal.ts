export enum IpcEvents {
    ADD_DEV_MODE_WINDOW = 'ADD_DEV_MODE_WINDOW',
    ADD_RUN_MODE_WINDOW = 'ADD_RUN_MODE_WINDOW',
    HIDE_BUILD_LOADING = 'HIDE_BUILD_LOADING'
}

import { } from 'electron';

export type IBrowserWindow = Electron.BrowserWindow & WindowData

export interface WindowData {
    data: {
        project: string;
        showLandingPage: boolean;
        isDevMode: boolean;
        appPath: string;
        home: string;
    }
}

export interface AutoUpdateInterface {
    releaseChannel: 'stable' | 'insiders';
    disableAutoUpdates: boolean;
}

export function getHashKeyForProject(key: string, projectFilePath: string): string {
    const boundsKey = 'Quark.HashKey.' + key;
    return (boundsKey + '.' + projectFilePath.replace(/[^a-zA-Z0-9]/g, '_')).replace('\.', '--');
}

export enum HASHED_KEYS {
    BG_COLOR = "BG_COLOR"
}

//relative to home
// const autoUpdatesFilePathRelativeToHome = './autoUpdates.json';
const remote = require('electron').remote;
const path = require('path');
export const autoUpdatesFilePath = remote ?
    path.join(remote.app.getPath('home'), '.quark', 'autoUpdates.json') :
    path.join(require('electron').app.getPath('home'), '.quark', 'autoUpdates.json');

export const mainProcessDataFilePath = remote ?
    path.join(remote.app.getPath('home'), '.quark', 'main-process-data.json') :
    path.join(require('electron').app.getPath('home'), '.quark', 'main-process-data.json');

export interface AppMainProcessData {
    bgColors: {
        [hashedKey: string]: string;
    }
}

export namespace electron {

    // var window = global;
    // const isElectron = window && window['process'] && window['process'].type;

    global.require = eval('require');
    const remote: Electron.Remote | undefined = global !== undefined ? global.require('electron').remote : undefined;
    export const module = global !== undefined ? global.require('electron') : null;
    export const mainProcess: NodeJS.Process = remote ? remote.process : null;
    export const fs: typeof import('fs-extra') = global !== undefined ? global.require('fs-extra') : null;
    export const path: typeof import('path') = global !== undefined ? global.require('path') : null;
    export const browserWindow: IBrowserWindow = remote ? remote.getCurrentWindow() as any : null;
}