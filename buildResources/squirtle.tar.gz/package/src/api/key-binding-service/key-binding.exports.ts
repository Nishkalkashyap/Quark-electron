import { keyBinding, IKeyBinding, ICondition, KeyCode } from './key-binding.service';
export { IKeyBinding, ICondition };

export namespace keyBindings {

    export function addDevTimeBinding(binding: IKeyBinding): void {
        keyBinding.addDevTimeBinding(binding);
    }

    export function addCondition(condition: ICondition): void {
        keyBinding.addCondition(condition);
    }

    export function getBindingForCommand(command: string): string | string[] | undefined {
        return keyBinding.getBindingForCommand(command);
    }
}
