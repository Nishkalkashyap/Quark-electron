import { Subject } from 'rxjs';
import { IDisposable } from '../../../exports';
import { storage } from '../storage/storage.exports';
import { commands } from '../commands-service/commands.exports';
import { Keys } from './../../../Keys';
import { throwError } from './../../../throw-error';
import { isDevMode } from './../../../internals.exports';

export interface ICondition {
    id: string;
    handle: () => boolean;
    thisArgs?: any;
}

export interface IKeyBinding {
    keybindings: string | string[];//['ctrl + k', 'command + k']
    command: string;//commandId
    when?: string;//ICondition Id
}

export interface IKeyBindingRegister {
    addKeyBinding: (keybindings: IKeyBinding['keybindings'], when?: string) => IKeyBindingRegister;
}

export enum KeyCode {
    SHIFT = 'shift',
    CTRL = 'ctrl',
    ALT = 'alt',
    META = 'meta',

    BACKSPACE = 'backspace',
    TAB = 'tab',
    ENTER = 'enter',
    RETURN = 'return',
    CAPSLOCK = 'capslock',
    ESC = 'esc',
    ESCAPE = 'escape',
    SPACE = 'space',
    PAGEUP = 'pageup',
    PAGEDOWN = 'pagedown',
    END = 'end',
    HOME = 'home',
    LEFT = 'left',
    UP = 'up',
    RIGHT = 'right',
    DOWN = 'down',
    INS = 'ins',
    DEL = 'del',
    PLUS = 'plus'
}


export class KeyBindingService {

    private _conditions: ICondition[] = [];
    public get conditions(): ICondition[] {
        return this._conditions;
    }

    public currentMode: 'runTimeBindings' | 'devTimeBindings' = 'devTimeBindings';
    private _devTimeBindings: IKeyBinding[] = [];
    public get devTimeBindings(): IKeyBinding[] { return this._devTimeBindings; }
    private _devTimeStore: IKeyBinding[];

    private get _event(): Subject<null> { return storage.inMemory.get(this._subjectKey) };

    constructor(private _subjectKey: string, private _devTimeStoreKey: string, private _runTimeStoreKey: string) {
        this._devTimeStore = storage.local.get(this._devTimeStoreKey, []);
    }

    public initialize() {
        this._event.subscribe(() => {
            storage.local.set(this._devTimeStoreKey, this._devTimeBindings);
            this._devTimeStore = storage.local.get(this._devTimeStoreKey, []);
        });
    }

    public addCondition(condition: ICondition): IDisposable {
        if (!(condition && condition.id && typeof condition.id == 'string')) {
            throwError('Condition id is not valid');
            return;
        }

        if (!(condition.handle && typeof condition.handle == 'function')) {
            throwError('Condition handle is not valid');
            return;
        }

        const find = this._conditions.find((val) => { return val.id == condition.id });

        if (find) {
            throwError('Condition already exists');
            return;
        }

        this._conditions.push(condition);

        let disposable: IDisposable = {
            dispose: () => {
                let index = this._conditions.findIndex((val) => { return val.id == condition.id });
                if (index !== -1) {
                    this._conditions.splice(index, 1);
                }
            }
        }

        return disposable;
    }

    public getBindingForCommand(command: string): IKeyBinding['keybindings'] | undefined {
        let find = this._devTimeBindings.find((val) => { return val.command === command });
        if (!find)
            return;

        return find.keybindings;
    }

    public addDevTimeBinding(binding: IKeyBinding): IKeyBindingRegister {
        this._addBinding(binding, this._devTimeBindings, this._devTimeStore, true);
        return this.getRegister(binding.command);
    }

    public updateBinding(old: IKeyBinding['keybindings'], newBinding: IKeyBinding) {
        const mousetrap: typeof import('mousetrap') = storage.inMemory.get(Keys.Mousetrap) as any;
        mousetrap.unbind(old);

        const index = this._devTimeBindings.findIndex((b) => {
            return b.command == newBinding.command;
        });
        this._devTimeBindings.splice(index, 1);
        this.addDevTimeBinding(newBinding);
    }

    public getRegister(id: string): IKeyBindingRegister {
        const register: IKeyBindingRegister = {
            addKeyBinding: (_keyBinding, when) => {
                return keyBinding.addDevTimeBinding({
                    command: id,
                    keybindings: _keyBinding,
                    when: when
                });
            }
        }
        return register;
    }

    private _addBinding(binding: IKeyBinding, arr: IKeyBinding[], store: IKeyBinding[], apply: boolean) {

        const mousetrap = storage.inMemory.get(Keys.Mousetrap) as any;

        if (!(binding.command && typeof binding.command == 'string')) {
            throwError('Command is not valid');
            return;
        }

        arr.push(binding);

        const find = store.find((val) => {
            return val.command == binding.command;
        });

        if (find) binding.keybindings = JSON.parse(JSON.stringify(find.keybindings));

        if (apply) {
            const findWhen = this._conditions.find((val) => { return val.id == binding.when });
            if (binding.when && findWhen) {
                mousetrap.bindGlobal(binding.keybindings, () => {
                    // console.log(document.activeElement);
                    if (!document.activeElement.classList.contains('key-binding-input-element')) {
                        this._runWithCondition(binding);
                    }
                });
            } else {
                mousetrap.bindGlobal(binding.keybindings, () => {
                    // console.log(document.activeElement);
                    if (!document.activeElement.classList.contains('key-binding-input-element')) {
                        commands.executeCommand(binding.command);
                    }
                });
            }
        }
    }

    private _runWithCondition(binding: IKeyBinding) {
        let bindings = this._devTimeBindings.filter((val) => {
            return (val.keybindings == binding.keybindings);
        }) || [];

        bindings.map((val) => {
            let conditionResult: boolean;
            let when = this._conditions.find((_when) => { return val.when == _when.id });

            if (!when) {
                throwError('Could not find the condition with the provided id');
                return;
            }

            if (when.thisArgs) {
                conditionResult = when.handle.bind(when.thisArgs)();
            } else {
                conditionResult = when.handle();
            }

            if (conditionResult) {
                commands.executeCommand(val.command);
            }
        });
    }

    public keyBindingInnerHTML(item: IKeyBinding['keybindings']): string {

        if (!item)
            return;

        if (Array.isArray(item)) {
            let str = '';
            const length = item.length;
            item.map((val, index) => {
                str = str.concat(getBinding(val));
                if (length - 1 != index) {
                    str = str.concat(' | ');
                }
            });
            return str;
        }

        return getBinding(item);


        function getBinding(_str: string): string {
            _str = _str.replace(/\s+/g, ' ');
            const item = _str.split(/[\s+]/g);

            let str = '';
            let length = item.length;

            item.map((val, index) => {
                str = str.concat(`<span class="key-button">${val}</span>`);
                if (length - 1 != index) {
                    str = str.concat(`<span class="key-plus"> + </span>`);
                }
            });
            return str;
        }
    }
}

export const keyBinding = new KeyBindingService(Keys.KeyBindingSubject, Keys.KeyBindingStoreDevTime, Keys.KeyBindingStoreRunTime);