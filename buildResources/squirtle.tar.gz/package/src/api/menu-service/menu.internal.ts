import { ContextMenuService, MenuService } from "./menu.service";
import { Keys } from './../../../Keys';

export { Menu as __Menu, ContextMenuTrigger } from './menu.service';

export const Menu = new MenuService();
export const contextMenu = new ContextMenuService(Keys.ContextMenuService);