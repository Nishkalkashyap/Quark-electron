import { contextMenu } from './menu.internal';
import { MenuItem, Menu } from './menu.service';
export { MenuItem, ContextMenuTrigger } from './menu.service';

export interface MenuRef {
    items: MenuItem[];
    dispose: () => void;
    update: (menu: MenuItem[]) => void;
}

export interface ContextMenuRef {
    items: MenuItem[];
    dispose: () => void;
    update: (menu: MenuItem[]) => void;

    show: (x: number, y: number) => void;
}

export namespace menu {

    export function createMenu(_menu: Menu): MenuRef {
        // return Menu.addMenu(_menu);
        return;
    }

    export function getMenuById(id: string): Menu {
        return menu.getMenuById(id);
    }

    export function getContextMenuById(id: string): Menu {
        return contextMenu.getMenuById(id);
    }
}