import { BehaviorSubject } from 'rxjs';
import { IDisposable } from '../../../exports';
import { storage } from '../storage/storage.exports';
import { throwError } from './../../../throw-error';

export interface Menu {
    id: string;
    menu: MenuItem[];
    name?: string;
    priority?: number;
}

export interface ContextMenuTrigger {
    id: string;
    x: number;
    y: number;
}

export interface MenuItem {
    label: string;
    command?: string | (() => void);
    children?: MenuItem[];
    divider?: boolean;
    icon?: string;
    disabled?: (() => boolean) | boolean;//todo in component
}

export class MenuService {
    protected _menus: Menu[] = [];
    public get menus() {
        return this._menus;
    }

    public addMenu(menu: Menu): IDisposable {
        let findIndex = this._menus.findIndex((val) => { return val.id == menu.id });
        if (!(findIndex == -1))
            throwError('Menu with the provided Id already exists.');

        this._menus.push(menu);

        let disposable: IDisposable = {
            dispose: () => {
                this._removeMenu(menu.id);
            }
        }

        return disposable;
    }

    private _removeMenu(id: string): Menu {
        let findIndex = this._menus.findIndex((val) => { return val.id == id });
        if (findIndex == -1)
            return;

        return this._menus.splice(findIndex, 1)[0];
    }

    public getMenuById(id: string): Menu {
        return this._menus.find((val) => { return val.id == id });
    }
}


export class ContextMenuService extends MenuService {

    private get _menuSubject(): BehaviorSubject<ContextMenuTrigger> {
        return storage.inMemory.get(this._key);
    }

    constructor(private _key: string) {
        super();
    }

    public showMenu(trigger: ContextMenuTrigger) {
        let findIndex = this._menus.findIndex((val) => { return val.id == trigger.id });
        if ((findIndex == -1))
            throwError('Menu with the provided Id does not exists.');

        this._menuSubject.next(trigger);
    }
}