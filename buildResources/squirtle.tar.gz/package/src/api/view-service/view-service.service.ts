import { IDisposable } from './../../../exports';
import { storage } from '../storage/storage.exports';
import { throwError } from './../../../throw-error';
import { views } from './view-service.internals';

abstract class ViewService {

    private _views: views.ViewProvider[] = [];
    protected _currentView: views.ViewProvider;
    public getCurrentView(): views.ViewProvider { return this._currentView; }
    public getAllViews(): views.ViewProvider[] { return this._views; }

    private _isNavbarVisible: boolean = true;
    public isNavbarVisible(): boolean { return this._isNavbarVisible; }
    public toggleNavbar(): void { this._isNavbarVisible = !this._isNavbarVisible; }
    public hideNavbar(): void { this._isNavbarVisible = false; }
    public showNavbar(): void { this._isNavbarVisible = true; }

    public selectNextView(): views.ViewProvider {
        const index = this._views.findIndex((v) => v == this._currentView);
        if (this._views.length == 1 || this._views.length == 0) {
            return this._currentView;
        }

        //If is last view
        if (index == this._views.length - 1) {
            this.setView(this._views[0]);
            return this._views[0];
        }

        this.setView(this._views[index + 1]);
        return this._views[index + 1];
    }

    public selectPreviousView(): views.ViewProvider {
        const index = this._views.findIndex((v) => v == this._currentView);
        if (this._views.length == 1 || this._views.length == 0) {
            return this._currentView;
        }

        //If is first view
        if (index == 0) {
            this.setView(this._views[this._views.length - 1]);
            return this._views[this._views.length - 1];
        }

        this.setView(this._views[index - 1]);
        return this._views[index - 1];
    }


    protected get _viewContainer(): HTMLDivElement {
        return storage.inMemory.get(this._key);
    }

    constructor(private _key: string) { }

    public triggerUpdate(): void {
        if (this._currentView) {
            this.setView(this._currentView);
        }
    }

    public registerView(view: views.ViewProvider): IDisposable {

        if (!(view instanceof views.ViewProvider))
            throwError('Input must be of type ViewProvider');

        const find = this._views.find((val) => { return val.getId() == view.getId() });
        if (find) {
            if (this._currentView != find) {
                this.setView(find);
            }
            return;
        }

        this._views.push(view);

        const disposable: IDisposable = {
            dispose: () => {
                this.removeView(view);
            }
        }

        return disposable;
    }

    public removeView(view: views.ViewProvider): void {
        const findIndex = this._views.findIndex((val) => { return val.getId() == view.getId() });
        if (findIndex == -1)
            return;
        this._removeViewHandle(view as any, findIndex);
    }

    protected async _removeViewHandle(view: views.ViewProvider, index: number) {

        const removeViewProvider = () => {
            let deletedView = this._views.splice(index, 1)[0];
            deletedView.element.remove();
            const length = this._views.length;
            if (view.onDidRemoveView && typeof view.onDidRemoveView == 'function') {
                try {
                    view.onDidRemoveView();
                } catch (err) {
                    throwError(err);
                }
            }
            if (length) {
                this.setView(this._views[length - 1]);
            }
        }

        if (view.onCanRemoveView && typeof view.onCanRemoveView == 'function') {
            try {
                const result = await view.onCanRemoveView();
                if (result) {
                    removeViewProvider();
                }
            } catch (err) {
                removeViewProvider();
                //default behaviour to remove
            }
        } else {
            removeViewProvider();
        }
    }

    public getViewById(id: string): views.ViewProvider | undefined {
        return this._views.find((view) => {
            return view.getId() == id;
        });
    }

    public async setView(_view: views.ViewProvider) {

        if (_view == null) {
            this._currentView = null;
            return;
        }

        if (!this._viewContainer) {
            setTimeout(() => {
                this.setView(_view);
            }, 100);
            return;
        }

        const view = this._views.find((val) => { return val.getId() == _view.getId() });
        if (!view) {
            throwError('View with the provided id does not exists');
            return;
        }

        if (_view == this._currentView && _view.element && _view.element.isConnected) {
            return;
        }

        if (isValidFunction(view.onCanEnterView)) {
            try {
                const result = await view.onCanEnterView();
                if (!result) {
                    return;
                }
            } catch (err) {
                //default behaviour to continue
            }
        }
        if (this._currentView) {
            let currentBottomViewElement = this._currentView.element;
            if (this._currentView.keepConnected) {
                currentBottomViewElement.style.maxHeight = '0px';
                currentBottomViewElement.style.minHeight = '0px';
                currentBottomViewElement.style.overflow = 'hidden';
                currentBottomViewElement.style.display = 'none';
                // currentBottomViewElement.remove();//cannot remove. Removes all input properties
            } else {
                isValidFunction(this._currentView.onWillRemoveElement) ? this._currentView.onWillRemoveElement() : null;
                currentBottomViewElement.remove();
                isValidFunction(this._currentView.onDidRemoveElement) ? this._currentView.onDidRemoveElement() : null;
            }
        }

        this._currentView = view;
        let viewElement: HTMLElement;
        if (view.keepConnected) {
            const find: HTMLElement = this._views.find((val) => { return val.getId() == view.getId() }).element;
            if (find.isConnected) {
                viewElement = find;
            } else {
                //no need to clone node. document.cteateElement('dsf').prop = {hello : 'test'} stays preserved
                viewElement = view.element;
                this._viewContainer.appendChild(viewElement);
                isValidFunction(view.onDidConnectElement) ? view.onDidConnectElement() : null;
            }
            viewElement.style.maxHeight = null;
            viewElement.style.minHeight = null;
            viewElement.style.overflow = null;
            viewElement.style.display = null;
        } else {
            isValidFunction(view.onWillCreateElement) ? view.onWillCreateElement() : null;//keep it here, user may want to change element
            viewElement = view.element.cloneNode() as any;
            this._currentView.element = viewElement;
            isValidFunction(view.onDidCreateElement) ? view.onDidCreateElement() : null;
            this._viewContainer.appendChild(viewElement);
            isValidFunction(view.onDidConnectElement) ? view.onDidConnectElement() : null;
        }

        this._currentView.element = viewElement;
        this._currentView.element.focus();
        isValidFunction(view.onDidEnterView) ? view.onDidEnterView() : null;
    }
}

function isValidFunction(func: Function): boolean {
    return func && typeof func == 'function';
}

abstract class VisibilityService extends ViewService {
    private _isVisible: boolean = true;
    public isVisible(): boolean { return this._isVisible; }
    public toggle(): void { this._isVisible = !this._isVisible; }
    public hide(): void { this._isVisible = false; }
    public show(): void { this._isVisible = true; }
}

export class SideViewService extends VisibilityService { };
export class BottomViewService extends VisibilityService { };
export class TabsViewService extends ViewService { };

const key = 'dfsnfkdsnkfnsdlfndskjfnkjdsnkdksdf-fdsdsfsdfdsd'

interface OverlayProviderContainerComponent {
    view: views.ViewProvider
}

export class OverlayViewService extends ViewService {

    constructor(_key: string, private _overlayProviderContainerTag: string) {
        super(_key);
    }

    private _minimizedViews: views.ViewProvider[] = [];
    public get minimizedViews(): views.ViewProvider[] {
        return this._minimizedViews;
    }

    // private _isMinimizedView(view: views.ViewProvider): boolean {
    //     return !!this._minimizedViews.find((v) => v == view);
    // }

    public async setView(_view: views.ViewProvider) {
        let view = this.getAllViews().find((val) => { return val.getId() == _view.getId() });
        if (!view) {
            console.log(_view.getId());
            throwError('View with the provided name does not exists');
            return;
        }

        if (_view.element.isConnected) {
            this._maximizeView(_view);
            this._currentView = _view;
            return;
        }

        let ele = document.createElement(this._overlayProviderContainerTag) as HTMLElement & OverlayProviderContainerComponent;
        ele.view = _view;
        _view[key] = ele;

        this._viewContainer.appendChild(ele);
    }

    public removeView(view: views.ViewProvider): void {
        let findIndex = this.getAllViews().findIndex((val) => { return val.getId() == view.getId() });
        if (findIndex == -1) {
            throwError('View with the provided name does not exists');
            return;
        }

        view[key].remove();
        this.getAllViews().splice(findIndex, 1);

        const minimized = this._minimizedViews.findIndex((val) => {
            return val.getId() == view.getId();
        });
        if (minimized !== -1) {
            this._minimizedViews.splice(minimized, 1);
        }
    }

    private _maximizeView(view: views.ViewProvider): void {
        let findIndex = this.getAllViews().findIndex((val) => { return val.getId() == view.getId() });
        if (findIndex == -1) {
            throwError('View with the provided name does not exists');
            return;
        }

        const element = (view[key] as HTMLElement).firstElementChild as HTMLElement;
        element.style.maxHeight = null;
        element.style.minHeight = null;
        element.style.height = null;
        element.style.border = null;

        const minimized = this._minimizedViews.findIndex((val) => {
            return val.getId() == view.getId();
        });
        if (minimized !== -1) {
            this._minimizedViews.splice(minimized, 1);
        }
    }

    private _minimizeView(view: views.ViewProvider): void {
        let findIndex = this.getAllViews().findIndex((val) => { return val.getId() == view.getId() });
        if (findIndex == -1) {
            throwError('View with the provided name does not exists');
            return;
        }

        let element = (view[key] as HTMLElement).firstElementChild as HTMLElement;
        element.style.maxHeight = '0px';
        element.style.minHeight = '0px';
        element.style.height = '0px';
        element.style.border = 'none';

        this._minimizedViews.push(view);
    }

    public hide() {
        // super.
    }

    // public show() {

    // }

    //extend VisibilityController
}