export { app, clipboard } from './native.service';
