
import { electron } from '../electron/electron.internal';

const dialog = electron.module.remote.dialog;
const shell = electron.module.remote.shell;
const _app = electron.module.remote.app;
const _clipboard = electron.module.remote.clipboard;

export namespace clipboard {
    export function readText(): string {
        return _clipboard.readText();
    }

    export function writeText(text: string): void {
        _clipboard.writeText(text);
    }

    export function clear(): void {
        _clipboard.clear();
    }
}

export namespace app {

    export function showItemInFolder(fullPath?: string): void {
        shell.showItemInFolder(fullPath || '');
    }

    export function beep(): void {
        shell.beep();
    }

    export function getAppMetrics(): Electron.ProcessMetric[] {
        return _app.getAppMetrics();
    }

    export function getAppPath(): string {
        return _app.getAppPath();
    }

    export function getVersion(): string {
        return _app.getVersion();
    }

    export function showMessageBox<T>(title: string, message: string, buttons: T[], type?: "none" | "info" | "error" | "question" | "warning"): Promise<T> {
        return new Promise((resolve) => {
            dialog.showMessageBox(electron.browserWindow, {
                type: type || 'warning',
                title: 'Quark',
                message: title,
                detail: message,
                noLink: true,
                buttons: buttons as any,
            }, (response: number) => {
                resolve(buttons[response]);
            });
        });
    }

    export function showErrorBox(title: string, content: string): void {
        dialog.showMessageBox(electron.browserWindow, {
            type: 'error',
            title: 'Error',
            message: title,
            detail: content,
            noLink: true,
            buttons: ['OK']
        }, () => null);
    }

    export function showOpenDialog(options?: Electron.OpenDialogOptions): Promise<{ filePaths: string[], bookmarks: string[] }> {
        return new Promise((resolve) => {
            dialog.showOpenDialog(electron.browserWindow, options, (filePaths, bookmarks) => {
                resolve({
                    filePaths,
                    bookmarks
                });
            });
        });
    }

    export function showSaveDialog(options?: Electron.SaveDialogOptions): Promise<{ filename: string, bookmark: string }> {
        return new Promise((resolve) => {
            dialog.showSaveDialog(electron.browserWindow, options, (filename, bookmark) => {
                resolve({
                    filename,
                    bookmark
                });
            });
        });
    }
}
