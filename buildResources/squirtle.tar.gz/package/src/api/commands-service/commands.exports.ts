import { ICommand, _commands } from './commands.service';
import { IKeyBindingRegister } from '../key-binding-service/key-binding.service';

export { ICommand };

export namespace commands {

    export function registerCommand(id: string, handle: Function, thisArg?: any, label?: string): IKeyBindingRegister {
        return _commands.registerCommand(id, handle, thisArg, label);
    }

    export function executeCommand(id: string, ...args: any[]): any {
        return _commands.executeCommand(id, ...args);
    }

    export function getCommand(id: string): ICommand | undefined {
        return _commands.getCommand(id);
    }

    export function getAllCommands(): ICommand[] {
        return _commands.commands;
    }
}