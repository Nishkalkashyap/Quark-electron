initializeWorkerPaths();
import { initializeWorkerPaths } from './../../../src/workers/workers.util';
import * as _webpack from 'webpack';
import * as merge from 'webpack-merge';
import { MessageData, Messages, WORKER_TO_WINDOW } from '../bundler.internal';
import { getMemoryFs, makeFilesystemFromObject } from './bundler.utils';
import { WindowData } from './../../../src/api/electron/electron.internal';
// const ctx = self as CustomWindow;
const ctx = self as any;
let windowData: WindowData['data'];
const Path: typeof import('path') = global.require('path');

const VueLoaderPlugin = global.require('vue-loader/lib/plugin');

// self['Buffer'] = global.require('buffer').Buffer;

// self.setTimeout = global.require('timers').setTimeout;
const vueStyleLoaderOptions = {
    loader: 'vue-style-loader',
    options: {
        shadowMode: false
    }
};

function babelPresetPath(preset: string) {
    const resolvedPath = ctx.require.resolve(preset, { paths: [windowData.appPath] });
    return resolvedPath;
}

function getBaseConfig() {
    const webpack: typeof _webpack = ctx.require('webpack');
    // const MiniCssExtractPlugin = ctx.require("mini-css-extract-plugin");
    let baseConfig: _webpack.Configuration = {
        mode: 'development',
        entry: {
            src: '/src/setup.js'
        },
        output: {
            path: '/out',
            filename: '[name].bundle.js',
            publicPath: '/static'
        },
        resolve: {
            extensions: [".ts", ".tsx", ".js", ".jsx", ".json"],
            modules: [
                //from worker.utils.ts
                Path.join(Path.dirname(windowData.project), 'node_modules'),
                Path.join(windowData.appPath, 'node_modules'),
                Path.join(windowData.home, 'packages', 'node_modules')
            ],
            alias: {
                '@project': Path.dirname(windowData.project),
            }
        },
        resolveLoader: {
            modules: [
                //from worker.utils.ts
                Path.join(Path.dirname(windowData.project), 'node_modules'),
                Path.join(windowData.appPath, 'node_modules'),
                Path.join(windowData.home, 'packages', 'node_modules')
            ]
        },
        module: {
            rules: [
                {
                    test: /\.vue$/,
                    loader: 'vue-loader'
                },
                {
                    test: /\.css$/,
                    oneOf: [
                        {
                            use: [
                                vueStyleLoaderOptions,
                                {
                                    loader: 'css-loader',
                                    options: {
                                        modules: true,
                                        localIdentName: '[local]'
                                    }
                                }
                            ]
                        },
                        {
                            use: [
                                vueStyleLoaderOptions,
                                'css-loader'
                            ]
                        }
                    ]
                },
                {
                    test: /\.scss$/,
                    use: [
                        'raw-loader',
                        {
                            loader: "stylus-loader"
                        }
                    ]
                },
                {
                    test: /\.(js|jsx|ts|tsx)$/,
                    // exclude: /node_modules/,
                    exclude: (file) => (
                        /node_modules/.test(file) &&
                        !/\.vue\.js/.test(file)
                    ),
                    use: {
                        loader: "babel-loader",
                        options: {
                            "presets": [
                                [
                                    babelPresetPath("@babel/preset-env"), {
                                        "targets": {
                                            "chrome": "69"
                                        }
                                    }
                                ],
                                [babelPresetPath("@babel/preset-typescript"), {
                                    isTSX: true,
                                    allExtensions: true
                                }],
                                babelPresetPath("@babel/preset-react")
                            ],
                            "plugins": [
                                babelPresetPath("@babel/plugin-proposal-class-properties"),
                                babelPresetPath("@babel/plugin-proposal-object-rest-spread"),
                                babelPresetPath("@babel/plugin-syntax-dynamic-import")
                            ]
                        }
                    }
                },
                // {
                //     test: /\.tsx?$/,
                //     loader: 'ts-loader',
                //     options: { appendTsSuffixTo: [/\.vue$/] }
                // },
                {
                    test: /\.html$/,
                    use: 'raw-loader'
                },
                {
                    test: /\.md$/,
                    use: [
                        {
                            loader: "html-loader"
                        },
                        {
                            loader: "markdown-loader",
                            options: {
                                /* your options here */
                            }
                        }
                    ]
                }
            ]
        },
        target: 'electron-renderer',
        externals: {
            "serialport": "require('serialport')",
            "johnny-five": "require('johnny-five')"
        },
        plugins: [
            new VueLoaderPlugin(),
            new webpack.ProvidePlugin({
                "React": "react",
            })
        ]
    }

    return baseConfig;
}

let finalConfig: _webpack.Configuration;

registerMessageHandler();

function registerMessageHandler() {
    ctx.onmessage = (event) => {
        const message: MessageData = event.data;
        if (message.message == Messages.webpackConfig) {

            let result: _webpack.Configuration;
            try {
                result = eval(message.data)
            } catch (err) {
                console.log(err);
            }

            finalConfig = merge.smart(getBaseConfig(), result || {});
            return;
        }

        if (message.message == Messages.bundle) {
            bundle(message.data, finalConfig || getBaseConfig()).catch(console.error);
            return;
        }

        if (message.message == Messages.parentBrowserWindow) {
            windowData = message.data;
            return;
        }
    };
}

export async function bundle(obj: object, config: _webpack.Configuration): Promise<string> {
    const fs = getMemoryFs();
    const webpack: typeof _webpack = ctx.require('webpack');
    fs.mkdirSync('/out');
    makeFilesystemFromObject(obj, fs);
    const nodeExternals = global.require('webpack-node-externals');
    const compiler = webpack(config);

    compiler.inputFileSystem = fs;
    compiler['resolvers'].normal.fileSystem = ctx.require('fs');
    compiler['resolvers'].context.fileSystem = ctx.require('fs');
    compiler.outputFileSystem = fs as any;
    try {
        const result = await runCompiler(compiler, fs, config);
        return result;
    } catch (err) {
        console.log(err);
    }
}


function runCompiler(compiler: _webpack.Compiler, fs: typeof import('fs'), config: _webpack.Configuration): Promise<string> {

    let filename: string = config.entry as any;
    if (typeof config.entry == 'object') {
        filename = Object.keys(config.entry)[0];
    }

    return new Promise((resolve) => {
        try {
            compiler.run((e, s) => {
                if (!s.compilation.errors.length) {

                    if (!fs.existsSync(`/out/${filename}.bundle.js`)) {
                        ctx.postMessage({
                            message: WORKER_TO_WINDOW.ERROR,
                            data: `Invalid filename: ${filename}; Please check the value of config.entry.`
                        });
                        resolve(`Invalid filename: ${filename}; Please check the value of config.entry.`);
                        return;
                    }

                    const output = fs.readFileSync(`/out/${filename}.bundle.js`).toString();
                    writeFile(output);
                    ctx.postMessage({
                        message: WORKER_TO_WINDOW.SUCCESS,
                        data: s.toString()
                    });
                    resolve(output);
                } else {
                    ctx.postMessage({
                        message: WORKER_TO_WINDOW.ERROR,
                        data: s.toString()
                    });
                    resolve(s.toString());
                }
            });
        } catch (err) {
            console.log(err);
            const _err: Error = err;
            ctx.postMessage({
                message: WORKER_TO_WINDOW.ERROR,
                data: _err
            });
            resolve(JSON.stringify(_err));
        }
    })
}


async function writeFile(file: string) {
    const fs: typeof import('fs') = global.require('fs')
    const dir = Path.dirname(windowData.project);
    const filename = Path.basename(windowData.project);
    const newFilePath = Path.join(dir, filename.replace(/(\.qrk)$/, '.build.qrk'));
    fs.writeFile(newFilePath, file, (err) => { console.log(err); });
}
