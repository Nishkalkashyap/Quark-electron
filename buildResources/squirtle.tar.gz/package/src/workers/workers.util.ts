import { MessageData, WORKER_TO_WINDOW } from './bundler.internal';

export interface CustomWindow extends Window {
    postMessage: (message: MessageData | WORKER_TO_WINDOW, targetOrigin?: string, transfer?: Transferable[]) => void
}

export function initializeWorkerPaths() {
    const Path: typeof import('path') = global.require('path');
    const paths = [
        Path.join(process.resourcesPath, 'app.asar', 'node_modules'),
        Path.join(process.resourcesPath, 'app', 'node_modules'),//when asar is disabled
        process.resourcesPath.replace(/electron[\\/]dist[\\/]resources/g, '')
    ];

    paths.map((path) => {
        global.require.main.paths.push(path);
    });

    // console.log(global.require.main.paths);
}