import { electron } from './src/api/electron/electron.internal';
export * from './src/api/quick-view/quick-view.internal';
export * from './src/api/settings/settings.internal';
export * from './src/api/snackbar-service/snackbar.internal';
export * from './src/api/status-bar-service/status-bar.internal';
export * from './src/api/menu-service/menu.internal';
export * from './src/api/key-binding-service/key-binding.internal';
export * from './src/api/electron/electron.internal';
export * from './src/api/window-handles/window.handles.internal';
export * from './src/api/commands-service/commands.internal';
export * from './src/api/output-channel/output-channel.internal';


export * from './src/workers/bundler.internal';

export * from './src/api/view-service/view-service.internals';

export const isDevMode: boolean = electron.browserWindow.data.isDevMode;
