import * as _exports from './internals.exports';
import Internals = _exports;
export default Internals;

declare global {

    interface Window {
        require: NodeRequire;
    }

    namespace NodeJS {
        interface Global {
            require: NodeRequire;
        }
    }
}


