export const Keys = {
    TabsViewProvider: 'Quark.Views.TabsViewProvider',
    SideViewProvider: 'Quark.Views.SideViewProvider',
    BottomViewProvider: 'Quark.Views.BottomViewProvider',
    OverlayViewProvider: 'Quark.Views.OverlayViewProvider',

    ContextMenuService: 'Quark.ContextMenuService',

    Snackbars: 'Quark.Snackbars',
    SnackbarsSubject: 'Quark.SnackbarsSubject',

    IconMir: 'Quark.IconService.Mir',
    IconDom: 'Quark.IconService.Dom',

    Settings: 'Quark.Settings',
    QuickViewElement: 'app-quick-view',

    KeyBindingStoreRunTime: 'Quark.KeyBinding.runtime',
    KeyBindingStoreDevTime: 'Quark.KeyBinding.devtime',
    KeyBindingSubject: 'Quark.KeyBinding.subject',

    BrowserFileSystem: 'Quark.BrowserFileSystem',

    Mousetrap: 'Quark.NgZone',

    ThemeChangeSubject : 'Quark.theme-change-cubject'
}