(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./embeddedSupport", "./languageModelCache", "./cssMode", "./javascriptMode", "./vue/vueMode", "./template/vueHTML"], factory);
    }
})(function (require, exports) {
    /*---------------------------------------------------------------------------------------------
     *  Copyright (c) Microsoft Corporation. All rights reserved.
     *  Licensed under the MIT License. See License.txt in the project root for license information.
     *--------------------------------------------------------------------------------------------*/
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    const embeddedSupport_1 = require("./embeddedSupport");
    const languageModelCache_1 = require("./languageModelCache");
    const cssMode_1 = require("./cssMode");
    const javascriptMode_1 = require("./javascriptMode");
    const vueMode_1 = require("./vue/vueMode");
    const vueHTML_1 = require("./template/vueHTML");
    function getLanguageModes(_ctx, supportedLanguages) {
        let documentRegions = languageModelCache_1.getLanguageModelCache(10, 60, document => embeddedSupport_1.getDocumentRegions(document));
        let modelCaches = [];
        modelCaches.push(documentRegions);
        const jsMode = javascriptMode_1.getJavascriptMode(documentRegions, _ctx);
        let modes = {
            vue: vueMode_1.getVueMode(),
            'vue-html': vueHTML_1.getVueHTMLMode(documentRegions, _ctx, jsMode),
            css: cssMode_1.getCSSMode(documentRegions),
            //   postcss: getPostCSSMode(documentRegions),
            //   scss: getSCSSMode(documentRegions),
            //   less: getLESSMode(documentRegions),
            //   stylus: getStylusMode(documentRegions),
            javascript: jsMode,
            tsx: jsMode,
            typescript: jsMode
        };
        return {
            getModeAtPosition(document, position) {
                let languageId = documentRegions.get(document).getLanguageAtPosition(position);
                if (languageId) {
                    return modes[languageId];
                }
                return null;
            },
            getModesInRange(document, range) {
                return documentRegions.get(document).getLanguageRanges(range).map(r => {
                    return {
                        start: r.start,
                        end: r.end,
                        mode: modes[r.languageId],
                        attributeValue: r.attributeValue
                    };
                });
            },
            getAllModesInDocument(document) {
                let result = [];
                for (let languageId of documentRegions.get(document).getLanguagesInDocument()) {
                    let mode = modes[languageId];
                    if (mode) {
                        result.push(mode);
                    }
                }
                return result;
            },
            getAllModes() {
                let result = [];
                for (let languageId in modes) {
                    let mode = modes[languageId];
                    if (mode) {
                        result.push(mode);
                    }
                }
                return result;
            },
            getMode(languageId) {
                return modes[languageId];
            },
            onDocumentRemoved(document) {
                modelCaches.forEach(mc => mc.onDocumentRemoved(document));
                for (let mode in modes) {
                    modes[mode].onDocumentRemoved(document);
                }
            },
            dispose() {
                modelCaches.forEach(mc => mc.dispose());
                modelCaches = [];
                for (let mode in modes) {
                    modes[mode].dispose();
                }
                modes = {};
            }
        };
    }
    exports.getLanguageModes = getLanguageModes;
});
