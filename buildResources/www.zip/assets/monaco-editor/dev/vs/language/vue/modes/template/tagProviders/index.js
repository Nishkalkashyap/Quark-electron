(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./htmlTags", "./vueTags", "./routerTags", "./elementTags", "./componentTags"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const htmlTags_1 = require("./htmlTags");
    const vueTags_1 = require("./vueTags");
    const routerTags_1 = require("./routerTags");
    const elementTags_1 = require("./elementTags");
    var componentTags_1 = require("./componentTags");
    exports.getComponentTags = componentTags_1.getComponentTags;
    // import * as ts from '../../../lib/typescriptServices';
    // import * as fs from 'fs';
    exports.allTagProviders = [
        htmlTags_1.getHTML5TagProvider(),
        vueTags_1.getVueTagProvider(),
        routerTags_1.getRouterTagProvider(),
        elementTags_1.getElementTagProvider()
    ];
    function getBasicTagProviders(setting) {
        return exports.allTagProviders.filter(p => !setting || setting[p.getId()] !== false);
    }
    exports.getBasicTagProviders = getBasicTagProviders;
    function getDefaultSetting(workspacePath) {
        const setting = {
            html5: true,
            vue: true,
            router: false,
            element: false
        };
        if (!workspacePath) {
            return setting;
        }
        try {
            // const packagePath = ts.findConfigFile(workspacePath, ts.sys.fileExists, 'package.json');
            // const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf-8'));
            // if (packageJson.dependencies['vue-router']) {
            //   setting['router'] = true;
            // }
            // if (packageJson.dependencies['element-ui']) {
            //   setting['element'] = true;
            // }
            // if (packageJson.dependencies['vue-onsenui']) {
            //   setting['onsen'] = true;
            // }
        }
        catch (e) { }
        return setting;
    }
    exports.getDefaultSetting = getDefaultSetting;
});
