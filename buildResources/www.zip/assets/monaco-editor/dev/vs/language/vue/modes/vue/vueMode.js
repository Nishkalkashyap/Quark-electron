(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./scaffoldCompletion"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const scaffoldCompletion_1 = require("./scaffoldCompletion");
    function getVueMode() {
        return {
            getId() {
                return 'vue';
            },
            doComplete(document, position) {
                const offset = document.offsetAt(position);
                const text = document.getText().slice(0, offset);
                const needBracket = /<\w*$/.test(text);
                const ret = scaffoldCompletion_1.doScaffoldComplete();
                // remove duplicate <
                if (needBracket) {
                    ret.items.forEach(item => {
                        item.insertText = item.insertText.slice(1);
                    });
                }
                return ret;
            },
            onDocumentRemoved() { },
            dispose() { }
        };
    }
    exports.getVueMode = getVueMode;
});
