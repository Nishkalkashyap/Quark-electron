(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NULL_HOVER = {
        contents: []
    };
    exports.NULL_SIGNATURE = {
        signatures: [],
        activeSignature: 0,
        activeParameter: 0,
    };
    exports.NULL_COMPLETION = {
        isIncomplete: false,
        items: [],
        label: '',
    };
    exports.nullMode = {
        getId: () => '',
        onDocumentRemoved() { },
        dispose() { },
        doHover: () => exports.NULL_HOVER,
        doComplete: () => exports.NULL_COMPLETION,
        doSignatureHelp: () => exports.NULL_SIGNATURE,
        findReferences: () => [],
    };
});
