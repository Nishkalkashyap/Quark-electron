(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./languageModelCache"], factory);
    }
})(function (require, exports) {
    /*---------------------------------------------------------------------------------------------
     *  Copyright (c) Microsoft Corporation. All rights reserved.
     *  Licensed under the MIT License. See License.txt in the project root for license information.
     *--------------------------------------------------------------------------------------------*/
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    const languageModelCache_1 = require("./languageModelCache");
    function getHTMLMode(htmlLanguageService) {
        let globalSettings = {};
        let htmlDocuments = languageModelCache_1.getLanguageModelCache(10, 60, document => htmlLanguageService.parseHTMLDocument(document));
        return {
            getId() {
                return 'html';
            },
            configure(options) {
                globalSettings = options;
            },
            doComplete(document, position, settings = globalSettings) {
                let options = settings && settings.html && settings.html.suggest;
                let doAutoComplete = settings && settings.html && settings.html.autoClosingTags;
                if (doAutoComplete) {
                    options.hideAutoCompleteProposals = true;
                }
                return htmlLanguageService.doComplete(document, position, htmlDocuments.get(document), options);
            },
            doHover(document, position) {
                return htmlLanguageService.doHover(document, position, htmlDocuments.get(document));
            },
            findDocumentHighlight(document, position) {
                return htmlLanguageService.findDocumentHighlights(document, position, htmlDocuments.get(document));
            },
            findDocumentLinks(document, documentContext) {
                return htmlLanguageService.findDocumentLinks(document, documentContext);
            },
            findDocumentSymbols(document) {
                return htmlLanguageService.findDocumentSymbols(document, htmlDocuments.get(document));
            },
            format(document, range, formatParams, settings = globalSettings) {
                let formatSettings = settings && settings.html && settings.html.format;
                if (!formatSettings) {
                    formatSettings = formatParams;
                }
                else {
                    formatSettings = merge(formatParams, merge(formatSettings, {}));
                }
                return htmlLanguageService.format(document, range, formatSettings);
            },
            // doAutoClose(document: TextDocument, position: Position) {
            // 	let offset = document.offsetAt(position);
            // 	let text = document.getText();
            // 	if (offset > 0 && text.charAt(offset - 1).match(/[>\/]/g)) {
            // 		return htmlLanguageService.doTagComplete(document, position, htmlDocuments.get(document));
            // 	}
            // 	return null;
            // },
            onDocumentRemoved(document) {
                htmlDocuments.onDocumentRemoved(document);
            },
            dispose() {
                htmlDocuments.dispose();
            }
        };
    }
    exports.getHTMLMode = getHTMLMode;
    ;
    function merge(src, dst) {
        for (var key in src) {
            if (src.hasOwnProperty(key)) {
                dst[key] = src[key];
            }
        }
        return dst;
    }
});
