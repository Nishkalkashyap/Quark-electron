(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "vscode-languageserver-types"], factory);
    }
})(function (require, exports) {
    /*---------------------------------------------------------------------------------------------
     *  Copyright (c) Microsoft Corporation. All rights reserved.
     *  Licensed under the MIT License. See License.txt in the project root for license information.
     *--------------------------------------------------------------------------------------------*/
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    const ls = require("vscode-languageserver-types");
    var Uri = monaco.Uri;
    var Range = monaco.Range;
    // --- diagnostics --- ---
    class DiagnostcsAdapter {
        constructor(_languageId, _worker) {
            this._languageId = _languageId;
            this._worker = _worker;
            this._disposables = [];
            this._listener = Object.create(null);
            const onModelAdd = (model) => {
                let modeId = model.getModeId();
                if (modeId !== this._languageId) {
                    return;
                }
                let handle;
                this._listener[model.uri.toString()] = model.onDidChangeContent(() => {
                    clearTimeout(handle);
                    handle = setTimeout(() => this._doValidate(model.uri, modeId), 500);
                });
                this._doValidate(model.uri, modeId);
            };
            const onModelRemoved = (model) => {
                monaco.editor.setModelMarkers(model, this._languageId, []);
                let uriStr = model.uri.toString();
                let listener = this._listener[uriStr];
                if (listener) {
                    listener.dispose();
                    delete this._listener[uriStr];
                }
            };
            this._disposables.push(monaco.editor.onDidCreateModel(onModelAdd));
            this._disposables.push(monaco.editor.onWillDisposeModel(model => {
                onModelRemoved(model);
            }));
            this._disposables.push(monaco.editor.onDidChangeModelLanguage(event => {
                onModelRemoved(event.model);
                onModelAdd(event.model);
            }));
            this._disposables.push({
                dispose: () => {
                    for (let key in this._listener) {
                        this._listener[key].dispose();
                    }
                }
            });
            monaco.editor.getModels().forEach(onModelAdd);
        }
        dispose() {
            this._disposables.forEach(d => d && d.dispose());
            this._disposables = [];
        }
        _doValidate(resource, languageId) {
            this._worker(resource).then(worker => {
                return worker.doValidation(resource.toString()).then(diagnostics => {
                    const markers = diagnostics.map(d => toDiagnostics(resource, d));
                    monaco.editor.setModelMarkers(monaco.editor.getModel(resource), languageId, markers);
                });
            }).then(undefined, err => {
                console.error(err);
            });
        }
    }
    exports.DiagnostcsAdapter = DiagnostcsAdapter;
    function toSeverity(lsSeverity) {
        switch (lsSeverity) {
            case ls.DiagnosticSeverity.Error: return monaco.Severity.Error;
            case ls.DiagnosticSeverity.Warning: return monaco.Severity.Warning;
            case ls.DiagnosticSeverity.Information:
            case ls.DiagnosticSeverity.Hint:
            default:
                return monaco.Severity.Info;
        }
    }
    function toDiagnostics(resource, diag) {
        let code = typeof diag.code === 'number' ? String(diag.code) : diag.code;
        return {
            severity: toSeverity(diag.severity),
            startLineNumber: diag.range.start.line + 1,
            startColumn: diag.range.start.character + 1,
            endLineNumber: diag.range.end.line + 1,
            endColumn: diag.range.end.character + 1,
            message: diag.message,
            code: code,
            source: diag.source
        };
    }
    // --- completion ------
    function fromPosition(position) {
        if (!position) {
            return void 0;
        }
        return { character: position.column - 1, line: position.lineNumber - 1 };
    }
    function fromRange(range) {
        if (!range) {
            return void 0;
        }
        return { start: fromPosition(range.getStartPosition()), end: fromPosition(range.getEndPosition()) };
    }
    function toRange(range) {
        if (!range) {
            return void 0;
        }
        return new Range(range.start.line + 1, range.start.character + 1, range.end.line + 1, range.end.character + 1);
    }
    function toCompletionItemKind(kind) {
        let mItemKind = monaco.languages.CompletionItemKind;
        switch (kind) {
            case ls.CompletionItemKind.Text: return mItemKind.Text;
            case ls.CompletionItemKind.Method: return mItemKind.Method;
            case ls.CompletionItemKind.Function: return mItemKind.Function;
            case ls.CompletionItemKind.Constructor: return mItemKind.Constructor;
            case ls.CompletionItemKind.Field: return mItemKind.Field;
            case ls.CompletionItemKind.Variable: return mItemKind.Variable;
            case ls.CompletionItemKind.Class: return mItemKind.Class;
            case ls.CompletionItemKind.Interface: return mItemKind.Interface;
            case ls.CompletionItemKind.Module: return mItemKind.Module;
            case ls.CompletionItemKind.Property: return mItemKind.Property;
            case ls.CompletionItemKind.Unit: return mItemKind.Unit;
            case ls.CompletionItemKind.Value: return mItemKind.Value;
            case ls.CompletionItemKind.Enum: return mItemKind.Enum;
            case ls.CompletionItemKind.Keyword: return mItemKind.Keyword;
            case ls.CompletionItemKind.Snippet: return mItemKind.Snippet;
            case ls.CompletionItemKind.Color: return mItemKind.Color;
            case ls.CompletionItemKind.File: return mItemKind.File;
            case ls.CompletionItemKind.Reference: return mItemKind.Reference;
        }
        return mItemKind.Property;
    }
    function fromCompletionItemKind(kind) {
        let mItemKind = monaco.languages.CompletionItemKind;
        switch (kind) {
            case mItemKind.Text: return ls.CompletionItemKind.Text;
            case mItemKind.Method: return ls.CompletionItemKind.Method;
            case mItemKind.Function: return ls.CompletionItemKind.Function;
            case mItemKind.Constructor: return ls.CompletionItemKind.Constructor;
            case mItemKind.Field: return ls.CompletionItemKind.Field;
            case mItemKind.Variable: return ls.CompletionItemKind.Variable;
            case mItemKind.Class: return ls.CompletionItemKind.Class;
            case mItemKind.Interface: return ls.CompletionItemKind.Interface;
            case mItemKind.Module: return ls.CompletionItemKind.Module;
            case mItemKind.Property: return ls.CompletionItemKind.Property;
            case mItemKind.Unit: return ls.CompletionItemKind.Unit;
            case mItemKind.Value: return ls.CompletionItemKind.Value;
            case mItemKind.Enum: return ls.CompletionItemKind.Enum;
            case mItemKind.Keyword: return ls.CompletionItemKind.Keyword;
            case mItemKind.Snippet: return ls.CompletionItemKind.Snippet;
            case mItemKind.Color: return ls.CompletionItemKind.Color;
            case mItemKind.File: return ls.CompletionItemKind.File;
            case mItemKind.Reference: return ls.CompletionItemKind.Reference;
        }
        return ls.CompletionItemKind.Property;
    }
    function toTextEdit(textEdit) {
        if (!textEdit) {
            return void 0;
        }
        return {
            range: toRange(textEdit.range),
            text: textEdit.newText
        };
    }
    function toCompletionItem(entry) {
        return {
            label: entry.label,
            insertText: entry.insertText,
            sortText: entry.sortText,
            filterText: entry.filterText,
            documentation: entry.documentation,
            detail: entry.detail,
            kind: toCompletionItemKind(entry.kind),
            textEdit: toTextEdit(entry.textEdit),
            data: entry.data
        };
    }
    function fromCompletionItem(entry) {
        let item = {
            label: entry.label,
            sortText: entry.sortText,
            filterText: entry.filterText,
            documentation: entry.documentation,
            detail: entry.detail,
            kind: fromCompletionItemKind(entry.kind),
            data: entry.data
        };
        if (typeof entry.insertText === 'object' && typeof entry.insertText.value === 'string') {
            item.insertText = entry.insertText.value;
            item.insertTextFormat = ls.InsertTextFormat.Snippet;
        }
        else {
            item.insertText = entry.insertText;
        }
        if (entry.range) {
            item.textEdit = ls.TextEdit.replace(fromRange(entry.range), item.insertText);
        }
        return item;
    }
    const emmetTriggerCharacters = ['!', '.', '}', ':', '*', '$', ']', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    class CompletionAdapter {
        constructor(_worker) {
            this._worker = _worker;
        }
        get triggerCharacters() {
            return [...emmetTriggerCharacters, '.', ':', '<', '"', '=', '/'];
        }
        provideCompletionItems(model, position, token) {
            const wordInfo = model.getWordUntilPosition(position);
            const resource = model.uri;
            return wireCancellationToken(token, this._worker(resource).then(worker => {
                return worker.doComplete(resource.toString(), fromPosition(position));
            }).then(info => {
                if (!info) {
                    return;
                }
                let items = info.items.map(entry => {
                    let item = {
                        label: entry.label,
                        insertText: entry.insertText,
                        sortText: entry.sortText,
                        filterText: entry.filterText,
                        documentation: entry.documentation,
                        detail: entry.detail,
                        kind: toCompletionItemKind(entry.kind),
                    };
                    if (entry.textEdit) {
                        item.range = toRange(entry.textEdit.range);
                        item.insertText = entry.textEdit.newText;
                    }
                    if (entry.insertTextFormat === ls.InsertTextFormat.Snippet) {
                        item.insertText = { value: item.insertText };
                    }
                    return item;
                });
                return {
                    isIncomplete: info.isIncomplete,
                    items: items
                };
            }));
        }
    }
    exports.CompletionAdapter = CompletionAdapter;
    function toMarkedStringArray(contents) {
        if (!contents) {
            return void 0;
        }
        if (Array.isArray(contents)) {
            return contents;
        }
        return [contents];
    }
    // --- definition ------
    function toLocation(location) {
        return {
            uri: Uri.parse(location.uri),
            range: toRange(location.range)
        };
    }
    // --- document symbols ------
    function toSymbolKind(kind) {
        let mKind = monaco.languages.SymbolKind;
        switch (kind) {
            case ls.SymbolKind.File: return mKind.Array;
            case ls.SymbolKind.Module: return mKind.Module;
            case ls.SymbolKind.Namespace: return mKind.Namespace;
            case ls.SymbolKind.Package: return mKind.Package;
            case ls.SymbolKind.Class: return mKind.Class;
            case ls.SymbolKind.Method: return mKind.Method;
            case ls.SymbolKind.Property: return mKind.Property;
            case ls.SymbolKind.Field: return mKind.Field;
            case ls.SymbolKind.Constructor: return mKind.Constructor;
            case ls.SymbolKind.Enum: return mKind.Enum;
            case ls.SymbolKind.Interface: return mKind.Interface;
            case ls.SymbolKind.Function: return mKind.Function;
            case ls.SymbolKind.Variable: return mKind.Variable;
            case ls.SymbolKind.Constant: return mKind.Constant;
            case ls.SymbolKind.String: return mKind.String;
            case ls.SymbolKind.Number: return mKind.Number;
            case ls.SymbolKind.Boolean: return mKind.Boolean;
            case ls.SymbolKind.Array: return mKind.Array;
        }
        return mKind.Function;
    }
    function toHighlighKind(kind) {
        let mKind = monaco.languages.DocumentHighlightKind;
        switch (kind) {
            case ls.DocumentHighlightKind.Read: return mKind.Read;
            case ls.DocumentHighlightKind.Write: return mKind.Write;
            case ls.DocumentHighlightKind.Text: return mKind.Text;
        }
        return mKind.Text;
    }
    class DocumentHighlightAdapter {
        constructor(_worker) {
            this._worker = _worker;
        }
        provideDocumentHighlights(model, position, token) {
            const resource = model.uri;
            return wireCancellationToken(token, this._worker(resource).then(worker => worker.findDocumentHighlights(resource.toString(), fromPosition(position))).then(items => {
                if (!items) {
                    return;
                }
                return items.map(item => ({
                    range: toRange(item.range),
                    kind: toHighlighKind(item.kind)
                }));
            }));
        }
    }
    exports.DocumentHighlightAdapter = DocumentHighlightAdapter;
    class DocumentLinkAdapter {
        constructor(_worker) {
            this._worker = _worker;
        }
        provideLinks(model, token) {
            const resource = model.uri;
            return wireCancellationToken(token, this._worker(resource).then(worker => worker.findDocumentLinks(resource.toString())).then(items => {
                if (!items) {
                    return;
                }
                return items.map(item => ({
                    range: toRange(item.range),
                    url: item.target
                }));
            }));
        }
    }
    exports.DocumentLinkAdapter = DocumentLinkAdapter;
    function fromFormattingOptions(options) {
        return {
            tabSize: options.tabSize,
            insertSpaces: options.insertSpaces
        };
    }
    class DocumentFormattingEditProvider {
        constructor(_worker) {
            this._worker = _worker;
        }
        provideDocumentFormattingEdits(model, options, token) {
            const resource = model.uri;
            return wireCancellationToken(token, this._worker(resource).then(worker => {
                return worker.format(resource.toString(), null, fromFormattingOptions(options)).then(edits => {
                    if (!edits || edits.length === 0) {
                        return;
                    }
                    return edits.map(toTextEdit);
                });
            }));
        }
    }
    exports.DocumentFormattingEditProvider = DocumentFormattingEditProvider;
    class DocumentRangeFormattingEditProvider {
        constructor(_worker) {
            this._worker = _worker;
        }
        provideDocumentRangeFormattingEdits(model, range, options, token) {
            const resource = model.uri;
            return wireCancellationToken(token, this._worker(resource).then(worker => {
                return worker.format(resource.toString(), fromRange(range), fromFormattingOptions(options)).then(edits => {
                    if (!edits || edits.length === 0) {
                        return;
                    }
                    return edits.map(toTextEdit);
                });
            }));
        }
    }
    exports.DocumentRangeFormattingEditProvider = DocumentRangeFormattingEditProvider;
    /**
     * Hook a cancellation token to a WinJS Promise
     */
    function wireCancellationToken(token, promise) {
        if (promise.cancel && token.onCancellationRequested) {
            // if ((<Promise<T>>promise).cancel) {
            token.onCancellationRequested(() => promise.cancel());
        }
        return promise;
    }
});
