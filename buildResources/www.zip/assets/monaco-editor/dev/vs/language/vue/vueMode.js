(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./workerManager", "./languageFeatures"], factory);
    }
})(function (require, exports) {
    /*---------------------------------------------------------------------------------------------
     *  Copyright (c) Microsoft Corporation. All rights reserved.
     *  Licensed under the MIT License. See License.txt in the project root for license information.
     *--------------------------------------------------------------------------------------------*/
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    const workerManager_1 = require("./workerManager");
    const languageFeatures = require("./languageFeatures");
    function setupMode(defaults) {
        let disposables = [];
        const client = new workerManager_1.WorkerManager(defaults);
        disposables.push(client);
        const worker = (...uris) => {
            return client.getLanguageServiceWorker(...uris);
        };
        let languageId = defaults.languageId;
        // all modes
        disposables.push(monaco.languages.registerCompletionItemProvider(languageId, new languageFeatures.CompletionAdapter(worker)));
        disposables.push(monaco.languages.registerDocumentHighlightProvider(languageId, new languageFeatures.DocumentHighlightAdapter(worker)));
        disposables.push(monaco.languages.registerLinkProvider(languageId, new languageFeatures.DocumentLinkAdapter(worker)));
        // only vue
        if (languageId === 'vue') {
            disposables.push(monaco.languages.registerDocumentFormattingEditProvider(languageId, new languageFeatures.DocumentFormattingEditProvider(worker)));
            disposables.push(monaco.languages.registerDocumentRangeFormattingEditProvider(languageId, new languageFeatures.DocumentRangeFormattingEditProvider(worker)));
            disposables.push(new languageFeatures.DiagnostcsAdapter(languageId, worker));
        }
    }
    exports.setupMode = setupMode;
});
