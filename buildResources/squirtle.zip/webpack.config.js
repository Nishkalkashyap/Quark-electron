const Path = require('path');


function babelPresetPath(preset) {
    const resolvedPath = require.resolve(preset, {
        paths: ['./']
    });
    return resolvedPath;
}

module.exports = {
    // mode: 'production',
    mode: 'development',
    devtool: false,
    entry: {
        "token": "./dist/src/workers/tokenizer/tokenizer.util.js",
        "bundler": "./dist/src/workers/bundler/bundler.worker.js",
        "eslint": "./dist/src/workers/eslint/eslint.index.js"
    },
    module: {
        rules: [{
                test: /\.(js|jsx|ts|tsx)$/,
                exclude: (file) => (
                    /node_modules/.test(file) &&
                    !/\.vue\.js/.test(file)
                ),
                use: {
                    loader: "babel-loader",
                    options: {
                        "presets": [
                            [
                                babelPresetPath("@babel/preset-env"), {
                                    "targets": {
                                        "chrome": "69"
                                    },
                                    modules: false
                                }
                            ],
                            [babelPresetPath("@babel/preset-typescript"), {
                                isTSX: true,
                                allExtensions: true
                            }],
                            babelPresetPath("@babel/preset-react")
                        ],
                        "plugins": [
                            babelPresetPath("@babel/plugin-proposal-class-properties"),
                            babelPresetPath("@babel/plugin-proposal-object-rest-spread")
                        ]
                    }
                }
            }

        ]
    },
    output: {
        // globalObject : 'self',
        filename: '[name].bundle.js',
        path: Path.resolve(__dirname, './webpack/dist'),
        libraryTarget: `this`,
        globalObject: `(typeof self !== 'undefined' ? self : this)`

         // globalObject : 'self',
        //  filename: '[name].bundle.js',
        //  path: Path.resolve(__dirname, './webpack/dist'),
        //  libraryTarget: `umd`,
        //  umdNamedDefine : true,
        //  library : '[name]',
        //  globalObject: `(typeof self !== 'undefined' ? self : this)`
    },
    target: 'electron-renderer'
}