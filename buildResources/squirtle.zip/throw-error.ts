export function throwError(input: any) {
    console.error(input);
    return;
    // throwError(input);
}