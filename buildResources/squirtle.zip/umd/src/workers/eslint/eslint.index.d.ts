export declare function verify(code: string, version: number): {
    markers: {
        startLineNumber: number;
        endLineNumber: number;
        startColumn: number;
        endColumn: number;
        message: string;
        severity: number;
        source: string;
    }[];
    version: number;
};
