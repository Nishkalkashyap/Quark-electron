import * as _webpack from 'webpack';
export declare function bundle(obj: object, config: _webpack.Configuration): Promise<string>;
