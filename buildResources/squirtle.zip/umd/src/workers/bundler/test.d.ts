export declare function hello(): void;
