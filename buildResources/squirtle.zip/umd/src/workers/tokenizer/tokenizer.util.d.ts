export declare const regexTokeniser: (file: string) => any[];
export default regexTokeniser;
