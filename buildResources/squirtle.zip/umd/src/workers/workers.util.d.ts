import { MessageData, WORKER_TO_WINDOW } from './bundler.internal';
export interface CustomWindow extends Window {
    postMessage: (message: MessageData | WORKER_TO_WINDOW, targetOrigin?: string, transfer?: Transferable[]) => void;
}
export declare function initializeWorkerPaths(): void;
