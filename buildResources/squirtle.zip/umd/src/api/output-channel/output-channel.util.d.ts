import { OutputChannel } from './output-channel.exports';
export declare function createOutputChannel(name: string): OutputChannel;
