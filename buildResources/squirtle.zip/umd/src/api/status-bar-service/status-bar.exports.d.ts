import { IDisposable } from './../../../exports';
export declare enum StatusBarAlignment {
    Left = 1,
    Right = 2
}
export declare class StatusBarItem {
    readonly alignment?: StatusBarAlignment;
    readonly priority?: number;
    private _text;
    text: string;
    private _transformedText;
    readonly transformedText: string;
    private textTransform;
    tooltip: string | undefined;
    color: string | undefined;
    backgroundColor: string | undefined;
    command: string | Function | undefined;
    private _isVisible;
    readonly isVisible: boolean;
    show(): void;
    hide(): void;
    private _isLoading;
    readonly isLoading: boolean;
    showLoading(): void;
    hideLoading(): void;
    dispose: IDisposable['dispose'];
    constructor(alignment?: StatusBarAlignment, priority?: number);
}
