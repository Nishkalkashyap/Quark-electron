import { StatusBarAlignment, StatusBarItem } from './status-bar.exports';
export declare function createStatusBarItem(alignment?: StatusBarAlignment, priority?: number): StatusBarItem;
