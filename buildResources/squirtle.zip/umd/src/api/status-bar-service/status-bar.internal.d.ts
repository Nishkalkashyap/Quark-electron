import { StatusBarService } from './status-bar.service';
export declare const statusbar: StatusBarService;
