import { QuickViewProxy } from './quick-view.internal';
export interface QuickInputButton {
    icon?: string;
    label: string;
    description?: string;
    detail?: string;
    endIcon?: string;
    endIconTooltip?: string;
    divider?: boolean;
    data?: any;
}
export declare class InputBox {
    private _id;
    readonly id: string;
    protected _quickViewProxy: QuickViewProxy;
    private _isVisible;
    readonly isVisible: boolean;
    password: boolean;
    ignoreFocusOut: boolean;
    ignoreHide: boolean;
    busy: boolean;
    value: string;
    placeholder: string;
    panelClass: string;
    onDidChangeValue: () => void;
    onKeyUp: (e?: KeyboardEvent) => void;
    onKeyDown: (e?: KeyboardEvent) => void;
    onDidAccept: () => void;
    prompt: string;
    validationMessage: string | undefined;
    show(): void;
    private _hideView;
    hide(): void;
    dispose(): void;
    onDidHide: () => void;
}
export declare class IQuickPick extends InputBox {
    matchOnDescription: boolean;
    matchOnDetail: boolean;
    onDidTriggerButton: (button?: QuickInputButton) => void;
    private _buttons;
    buttons: QuickInputButton[];
    readonly selectedButton: QuickInputButton;
}
