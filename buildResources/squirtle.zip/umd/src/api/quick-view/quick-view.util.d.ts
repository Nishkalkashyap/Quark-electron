import { IQuickPick, InputBox } from './quick-view.exports';
export declare function createQuickView(): IQuickPick;
export declare function createInputBox(): InputBox;
