export declare type AppTheme = Partial<Theme>;
export interface Theme {
    'background.default': string;
    'on.background.default': string;
    'background.light': string;
    'on.background.light': string;
    'background.dark': string;
    'on.background.dark': string;
    'on.background.hint': string;
    'background.hover': string;
    'background.divider': string;
    'primary.default': string;
    'on.primary.default': string;
    'secondary.default': string;
    'on.secondary.default': string;
    'success.default': string;
    'on.success.default': string;
    'warning.default': string;
    'on.warning.default': string;
    'danger.default': string;
    'on.danger.default': string;
}
