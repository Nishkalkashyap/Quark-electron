export declare function registerOnQuitHandle(func: Function): void;
export declare function createElementFromHtml(html: string): HTMLElement;
