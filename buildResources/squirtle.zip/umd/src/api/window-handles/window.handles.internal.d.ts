export declare const handles: Function[];
export declare function runOnQuitHandles(): Promise<boolean>;
