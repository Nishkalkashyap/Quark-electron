export { textToWorker } from 'text-to-worker';
export declare function registerOnQuitHandle(func: Function): void;
export declare function createElementFromHtml(html: string): HTMLElement;
export declare function createVueWebComponent(name: string, data: Vue.ComponentOptions<any>, createElement: boolean): undefined | HTMLElement;
