import { IKeyBinding, ICondition } from './key-binding.service';
export { IKeyBinding, ICondition };
export declare namespace keyBindings {
    function addDevTimeBinding(binding: IKeyBinding): void;
    function addCondition(condition: ICondition): void;
    function getBindingForCommand(command: string): string | string[] | undefined;
}
