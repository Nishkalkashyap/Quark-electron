export interface ISnackbarButton {
    label: string;
    handle: () => void;
    icon?: string;
}
export declare abstract class SnackbarItem {
    message: string;
    type?: 'danger' | 'success' | 'warning' | 'info';
    duration?: number;
    show(): void;
    dispose(): void;
    private _id;
    readonly id: string;
    buttons: ISnackbarButton[];
    element: HTMLElement;
    constructor(message: string, type?: 'danger' | 'success' | 'warning' | 'info', duration?: number);
}
export declare class SnackbarService {
    private _snackbarKey;
    private _subjectKey;
    private readonly _snackbars;
    private readonly _subject;
    constructor(_snackbarKey: string, _subjectKey: string);
    removeSnackbar(id: string): void;
    addSnackbar(_snackbar: SnackbarItem): void;
}
export declare const snackbar: SnackbarService;
