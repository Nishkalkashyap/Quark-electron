import { IDisposable } from '../../../exports';
export interface Menu {
    id: string;
    menu: MenuItem[];
    name?: string;
    priority?: number;
}
export interface ContextMenuTrigger {
    id: string;
    x: number;
    y: number;
}
export interface MenuItem {
    label: string;
    command?: string | (() => void);
    children?: MenuItem[];
    divider?: boolean;
    icon?: string;
    disabled?: (() => boolean) | boolean;
}
export declare class MenuService {
    protected _menus: Menu[];
    readonly menus: Menu[];
    addMenu(menu: Menu): IDisposable;
    private _removeMenu;
    getMenuById(id: string): Menu;
}
export declare class ContextMenuService extends MenuService {
    private _key;
    private readonly _menuSubject;
    constructor(_key: string);
    showMenu(trigger: ContextMenuTrigger): void;
}
