import { MenuItem, ContextMenuRef, MenuRef } from './menu.exports';
export declare function createContextMenu(items: MenuItem[]): ContextMenuRef;
export declare function createMainMenuItem(name: string, items: MenuItem[], priority?: number): MenuRef;
