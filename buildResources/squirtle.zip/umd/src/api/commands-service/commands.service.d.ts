import { IKeyBindingRegister } from '../key-binding-service/key-binding.service';
export interface ICommand {
    id: string;
    handle: Function;
    thisArg?: any;
    label?: string;
    dispose: () => void;
}
export declare class CommandsService {
    private _commands;
    readonly commands: ICommand[];
    registerCommand(id: string, handle: Function, thisArg?: any, label?: string): IKeyBindingRegister;
    private _dispose;
    getCommand(id: string): ICommand | undefined;
    executeCommand(id: string, ...args: any[]): any;
}
export declare const _commands: CommandsService;
export declare const quickView: import("../quick-view/quick-view.exports").IQuickPick;
