import { ICommand } from './commands.service';
import { IKeyBindingRegister } from '../key-binding-service/key-binding.service';
export { ICommand };
export declare namespace commands {
    function registerCommand(id: string, handle: Function, thisArg?: any, label?: string): IKeyBindingRegister;
    function executeCommand(id: string, ...args: any[]): any;
    function getCommand(id: string): ICommand | undefined;
    function getAllCommands(): ICommand[];
}
