export { views } from './view-service.internals';
