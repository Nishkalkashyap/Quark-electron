import { ContextMenuRef } from "../menu-service/menu.exports";
import { SideViewService, BottomViewService, OverlayViewService, TabsViewService } from './view-service.service';
interface BaseController {
    getCurrentView(): views.ViewProvider;
    getAllViews(): views.ViewProvider[];
    isNavbarVisible(): boolean;
    toggleNavbar(): void;
    hideNavbar(): void;
    showNavbar(): void;
    selectNextView(): views.ViewProvider;
    selectPreviousView(): views.ViewProvider;
    triggerUpdate(): void;
    removeView(view: views.ViewProvider): void;
    getViewById(id: string): views.ViewProvider | undefined;
    setView(_view: views.ViewProvider): void;
}
interface VisibilityController {
    isVisible(): boolean;
    toggle(): void;
    hide(): void;
    show(): void;
    maximize(): void;
    minimize(): void;
}
export { SideViewService, BottomViewService, OverlayViewService, TabsViewService };
export declare const _sideviewController: SideViewService;
export declare const _bottomviewController: BottomViewService;
export declare const _tabsviewController: TabsViewService;
export declare const _overlayviewController: OverlayViewService;
export declare namespace views {
    interface SideviewController extends BaseController, VisibilityController {
    }
    interface BottomviewController extends BaseController, VisibilityController {
    }
    interface OverlayviewController extends BaseController, VisibilityController {
    }
    interface TabsviewController extends BaseController {
    }
    interface ButtonField {
        label: string;
        handle: () => void;
        icon?: string;
    }
    interface _SelectField {
        placeholder: string;
        currentValue: string;
        isHidden: boolean;
        handle: (option?: string) => void;
        options: string[];
        viewOptions: string[];
    }
    type SelectField = Partial<_SelectField>;
    type InputField = Partial<_InputField>;
    interface _InputField {
        placeholder: string;
        currentValue: string;
        isHidden: boolean;
        handle: (value?: string) => void;
    }
    class ViewProvider {
        label: string;
        element: HTMLElement;
        readonly keepConnected?: boolean;
        dispose: () => void;
        private _isVisible;
        isVisible(): boolean;
        hide: () => void;
        show(): void;
        isFocused: () => boolean;
        focus: () => void;
        blur: () => void;
        private _id;
        getId(): string;
        setId: (id: string) => void;
        actionIconClickHandle: () => void;
        private _progressBarValue;
        getProgressBarValue(): number | 'indeterminate';
        setProgressBar(val?: number): void;
        hideProgressBar(): void;
        onWillCreateElement: () => void;
        onDidCreateElement: () => void;
        onDidConnectElement: () => void;
        onWillRemoveElement: () => void;
        onDidRemoveElement: () => void;
        onCanEnterView: () => Promise<boolean> | boolean;
        onDidEnterView: () => void;
        onCanRemoveView: () => Promise<boolean> | boolean;
        onDidRemoveView: () => void;
        constructor(label: string, element: HTMLElement, keepConnected?: boolean, id?: string);
        busy: boolean;
        badge: string | number;
        icon: string;
        tooltip: string;
        data: any;
        actionIcon: string;
        contextMenu: ContextMenuRef;
        buttons: ButtonField[];
        inputField: InputField;
        selectField: SelectField;
    }
    const sideviewController: SideviewController;
    const bottomviewController: BottomviewController;
    const tabsviewController: TabsviewController;
    const overlayviewController: OverlayviewController;
    function createSideView(label: string, element?: HTMLElement, keepConnected?: boolean, id?: string): ViewProvider;
    function createBottomView(label: string, element?: HTMLElement, keepConnected?: boolean, id?: string): ViewProvider;
    function createTabsView(label: string, element?: HTMLElement, keepConnected?: boolean, id?: string): ViewProvider;
}
