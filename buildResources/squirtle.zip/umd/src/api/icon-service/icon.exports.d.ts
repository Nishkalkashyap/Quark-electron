import { IconService } from './icon.service';
export { Icon } from './icon.service';
export declare const icons: IconService;
