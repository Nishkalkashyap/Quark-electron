abstract class __Store {
    protected _object: any;
    get<T>(key: string, defaultValue?: T): T | undefined;
    set<T>(path: string, value: T): T;
    update<T, P>(path: string, updater: (value: T) => P): T;
    has(path: string): boolean;
    delete(path: string): void;
    readonly size: number;
}
export declare class MemoryStore extends __Store {
}
export declare class PersistantStore extends __Store {
    private _store;
    private _lastWrittenObject;
    private _watcher;
    private _changeHandles;
    readonly store: any;
    constructor(options: StoreOptions);
    forceUpdate(key?: string): void;
    onDidChange<K extends keyof T, T>(key: string, callback: (newValue: T[K], oldValue: T[K]) => void): void;
}
interface StoreOptions {
    defaults?: any;
    name?: string;
    cwd?: string;
    fileExtension?: string;
    encryptionKey?: string | Buffer;
}
export declare namespace storage {
    const inMemory: MemoryStore;
    const local: PersistantStore;
    const global: PersistantStore;
}
export {};
