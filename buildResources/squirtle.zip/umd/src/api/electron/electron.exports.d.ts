export { window } from './electron.service';
