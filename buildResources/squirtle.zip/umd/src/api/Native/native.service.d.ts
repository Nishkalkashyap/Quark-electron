export declare namespace clipboard {
    function readText(): string;
    function writeText(text: string): void;
    function clear(): void;
}
export declare namespace app {
    function showItemInFolder(fullPath?: string): void;
    function beep(): void;
    function getAppMetrics(): Electron.ProcessMetric[];
    function getAppPath(): string;
    function getVersion(): string;
    function showMessageBox<T>(title: string, message: string, buttons: T[], type?: "none" | "info" | "error" | "question" | "warning"): Promise<T>;
    function showErrorBox(title: string, content: string): void;
    function showOpenDialog(options?: Electron.OpenDialogOptions): Promise<{
        filePaths: string[];
        bookmarks: string[];
    }>;
    function showSaveDialog(options?: Electron.SaveDialogOptions): Promise<{
        filename: string;
        bookmark: string;
    }>;
}
