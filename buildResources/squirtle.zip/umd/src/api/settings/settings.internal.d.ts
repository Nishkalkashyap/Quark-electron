import { SettingScope, Item, Group, Namespace, Iobject } from './settings.circular';
import { IDisposable } from './../../../exports';
export * from './settings.circular';
export declare namespace settings {
    function getItemValue(id: string): unknown;
    function watchSettingItem(id: string, watcher: _Settings.OnDidChangeInterface['handle']): IDisposable;
    function addNamespace(namespace: Namespace): void;
}
export declare namespace _Settings {
    let currentScope: SettingScope;
    const array: {
        global: InternalNamespace[];
        local: InternalNamespace[];
    };
    const onDidChangeHandles: OnDidChangeInterface[];
    let currentNamespace: InternalNamespace;
    function updateSettings(item: Item): void;
    function isChangedInOtherScope(item: Item): boolean;
    function getCopy(item: any): any;
    interface OnDidChangeInterface {
        id: string;
        handle: (value?: any, scope?: SettingScope) => void;
    }
    interface InternalGroup extends Group {
        itemIds: string[];
    }
    interface InternalNamespace extends Namespace {
        groupIds: string[];
        groups: InternalGroup[];
    }
    function getObjectFromIobject(_obj: Iobject[]): object;
}
