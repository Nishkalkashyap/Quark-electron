import { WatchOptions } from 'chokidar';
import { Watcher } from './file-watcher.exports';
export declare function createFileSystemWatcher(paths: string | string[], options?: WatchOptions): Watcher;
