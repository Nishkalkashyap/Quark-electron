import * as quark from './exports';
export default quark;
