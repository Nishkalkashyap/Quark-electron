export * from './src/api/storage/storage.exports';
export * from './src/api/commands-service/commands.exports';
export * from './src/api/icon-service/icon.exports';
export * from './src/api/key-binding-service/key-binding.exports';
export * from './src/api/menu-service/menu.exports';
export * from './src/api/quick-view/quick-view.exports';
export * from './src/api/snackbar-service/snackbar.exports';
export * from './src/api/status-bar-service/status-bar.exports';
export * from './src/api/view-service/view-service.exports';
export * from './src/api/file-watcher/file-watcher.exports';
export * from './src/api/output-channel/output-channel.exports';
export * from './src/api/Theme/theme.exports';
export * from './src/api/Native/native.exports';
export * from './src/api/electron/electron.exports';
import * as _util from './util';
export import util = _util;
export declare class IDisposable {
    dispose: () => void;
}
