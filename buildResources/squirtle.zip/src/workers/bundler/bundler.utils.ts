export function makeFilesystemFromObject(obj: object, fs: typeof import('fs')) {
    Object.keys(obj).map((key) => {
        if (typeof obj[key] == 'object') {
            fs.mkdirSync(key);
            makeFilesystemFromObject(obj[key], fs);
        } else {
            fs.writeFileSync(key, obj[key].length == 0 ? '     ' : obj[key]);
        }
    });
}


export function getMemoryFs(): typeof import('fs') {
    const nodeFs = global.require('fs');
    const MemoryFileSystem = global.require('memory-fs');
    const memFs = new MemoryFileSystem();
    const statOrig = memFs.stat.bind(memFs);
    const readFileOrig = memFs.readFile.bind(memFs);
    memFs.stat = function (_path, cb) {
        statOrig(_path, function (err, result) {
            if (err) {
                return nodeFs.stat(_path, cb);
            } else {
                return cb(err, result);
            }
        });
    };
    memFs.readFile = function (path, cb) {
        readFileOrig(path, function (err, result) {
            if (err) {
                return nodeFs.readFile(path, cb);
            } else {
                return cb(err, result);
            }
        });
    };

    return memFs;
}