export enum Messages {
    bundle,
    parentBrowserWindow,
    webpackConfig
}

export enum WORKER_TO_WINDOW {
    ERROR = 'a',
    SUCCESS = 'b',
    tokenizeFile = 'tokenizeFile'
}

export enum WINDOW_TO_WORKER {
    tokenizeFile = 'tokenizeFile'
}

export interface MessageData<T = any> {
    message: Messages | WORKER_TO_WINDOW | WINDOW_TO_WORKER;
    data: T;
}