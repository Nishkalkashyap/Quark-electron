const findConstants = /export[ \t\n]+(?:declare[ \t\n]+)?(const +enum|default|class|interface|let|var|const|enum|type|function)[ \t\n]+([^=\n\t (:;<]+)/g
const findDynamics = /export +{([^}]+)}/g

export const regexTokeniser = (file: string) => {
    // const imports = new Array<Import>()
    const imports = new Array<any>()

    // Extract constants
    {
        const matches = getMatches(file, findConstants)
        const imps = matches.map(([_, type, name]) => ({ type, name }))
        imports.push(...imps)
    }

    // Extract dynamic imports
    {
        const matches = getMatches(file, findDynamics)
        const flattened: string[] = [].concat(
            ...matches.map(([_, imps]) => imps.split(','))
        )

        // Resolve 'import as export'
        const resolvedAliases = flattened.map(raw => {
            const [imp, alias] = raw.split(' as ')
            return alias || imp
        })

        // Remove all whitespaces + newlines
        const trimmed = resolvedAliases.map(imp => imp.trim().replace(/\n/g, ''))

        const imps = trimmed.map(
            (name): any => ({
                name,
                type: 'any'
            })
        )

        imports.push(...imps)
    }

    return imports
}

const getMatches = (string: string, regex: RegExp) => {
    const matches = []
    let match
    while ((match = regex.exec(string))) {
        matches.push(match)
    }
    return matches
}

export default regexTokeniser