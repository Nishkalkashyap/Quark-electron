import regexTokeniser from './tokenizer.util';
import { MessageData, WINDOW_TO_WORKER, WORKER_TO_WINDOW } from '../bundler.internal';

const ctx = self as any;

registerMessageHandler();

export { regexTokeniser };

export function add(a: number, b: number) {
    // block for half a second to demonstrate asynchronicity
    let start = Date.now();
    while (Date.now() - start < 500);
    return (a + b);
}

function registerMessageHandler() {
    console.log('Tokenizer initiated');

    ctx.onmessage = (event) => {
        const message: MessageData = event.data;

        if (message.message == WINDOW_TO_WORKER.tokenizeFile) {
            const file: { [path: string]: string } = message.data;
            Object.keys(file).map((key) => {
                const _File: any = {
                    path: key,
                    imports: regexTokeniser(file[key])
                }
                ctx.postMessage({
                    message: WORKER_TO_WINDOW.tokenizeFile,
                    data: JSON.stringify(_File)
                });
            });
        }
    }
}