import { IconService } from './icon.service';
import { Keys } from './../../../Keys';
export { Icon } from './icon.service';

export const icons: IconService = new IconService(Keys.IconMir, Keys.IconDom);