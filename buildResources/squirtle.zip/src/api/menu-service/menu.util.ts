import { MenuItem, ContextMenuRef, MenuRef } from './menu.exports';
import { contextMenu, Menu } from './menu.internal';

export function createContextMenu(items: MenuItem[]): ContextMenuRef {
    const id = (Date.now() + Math.random()).toString();
    const disposable = contextMenu.addMenu({
        id,
        menu: items
    });
    const update = (menu: MenuItem[]): void => {
        items.length = 0;
        menu.map((val) => {
            items.push(val);
        });
    }

    const ref: ContextMenuRef = {
        dispose: disposable.dispose,
        show: (x: number, y: number) => {
            contextMenu.showMenu({
                id,
                x,
                y,
            });
        },
        items,
        update
    }

    return ref;
}

export function createMainMenuItem(name: string, items: MenuItem[], priority?: number) {
    const id = (Date.now() + Math.random()).toString();
    const disposable = Menu.addMenu({
        id,
        menu: items,
        name: name,
        priority
    });

    const update = (menu: MenuItem[]): void => {
        items.length = 0;
        menu.map((val) => {
            items.push(val);
        });
    };

    const ref: MenuRef = {
        dispose: disposable.dispose,
        items,
        update
    }

    return ref;
}