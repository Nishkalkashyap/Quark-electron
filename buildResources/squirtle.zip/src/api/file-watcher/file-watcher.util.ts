import { WatchOptions } from 'chokidar';
import { Watcher } from './file-watcher.exports';

export function createFileSystemWatcher(paths: string | string[], options?: WatchOptions): Watcher {
    const _watch = window.require('chokidar').watch;
    return _watch(paths, options);
}

