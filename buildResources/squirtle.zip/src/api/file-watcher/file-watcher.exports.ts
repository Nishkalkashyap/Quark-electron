import { FSWatcher } from 'chokidar';
export { WatchOptions, WatchedPaths, AwaitWriteFinishOptions } from 'chokidar';
export type WatchEvents = 'add' | 'addDir' | 'change' | 'unlink' | 'unlinkDir' | 'ready' | 'raw' | 'error' | 'all';

export interface Watcher extends FSWatcher {
    // on(event: WatchEvents, listener: (path?: string) => void): this;
    // on(event: 'all', listener: (event?: WatchEvents, path?: string) => void): this;
}