import { AppTheme } from './theme.exports';
import { BehaviorSubject } from 'rxjs';
import { storage } from '../storage/storage.exports';
import { Keys } from './../../../Keys';

export function setAppTheme(theme: AppTheme) {
    const subject: BehaviorSubject<AppTheme> = storage.inMemory.get(Keys.ThemeChangeSubject);
    addCssVariables(theme);
    subject.next(theme);
    function addCssVariables(variables: AppTheme = {} as any) {
        for (let key in variables) {
            key = key || '';
            document.documentElement.style.setProperty(`--${key.replace(/\./g, '-')}`, variables[key] || '');
        }
    }
}