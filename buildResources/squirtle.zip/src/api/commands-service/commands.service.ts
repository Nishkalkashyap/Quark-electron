import { keyBinding, IKeyBindingRegister } from '../key-binding-service/key-binding.service';
import { createQuickView } from '../quick-view/quick-view.util';
import { throwError } from './../../../throw-error';

export interface ICommand {
    id: string;
    handle: Function;
    thisArg?: any;
    label?: string;
    dispose: () => void
}

export class CommandsService {
    private _commands: ICommand[] = [];
    public get commands(): ICommand[] {
        return this._commands;
    }

    public registerCommand(id: string, handle: Function, thisArg?: any, label?: string): IKeyBindingRegister {

        if (!(id && typeof id == 'string')) {
            throwError('Id must be of type string');
            return;
        }

        if (!(handle && typeof handle == 'function')) {
            throwError('handle must be of type funstion');
            return;
        }

        const find = this._commands.find((val) => { return val.id == id });
        if (find) {
            throwError(`Command with the provided id ${find.id} already exists`);
            return;
        }

        const dispose = () => {
            this._dispose(id);
        }

        this._commands.push({
            id,
            handle,
            thisArg,
            label,
            dispose
        });

        if (label) {
            setTimeout(() => {
                registerInQuickActions(id, label);
            }, 100);
        }

        return keyBinding.getRegister(id);
    }

    private _dispose(id: string): void {
        const index = this._commands.findIndex((c) => c.id == id);
        if (index !== -1) {
            this._commands.splice(index, 1);
        }
    }

    public getCommand(id: string): ICommand | undefined {
        return this._commands.find((val) => { return val.id == id });
    }


    public executeCommand(id: string, ...args: any[]): any {
        const find: ICommand | undefined = this._commands.find((val) => { return val.id == id });
        if (!find) {
            throwError('Command with the provided Id does not exists');
            return;
        }

        if (find.thisArg) {
            return find.handle.bind(find.thisArg)(args);
        } else {
            return find.handle(args);
        }
    }
}

export const _commands: CommandsService = new CommandsService();
export const quickView = createQuickView();

quickView.onDidAccept = function () {
    if (quickView.selectedButton) {
        const commandId = quickView.selectedButton.data;
        _commands.executeCommand(commandId);
    }
}

quickView.onDidHide = () => {
    quickView.value = '';
}

// quickView.ignoreFocusOut = true;

function registerInQuickActions(commandId: string, label: string) {

    const keyBindings = keyBinding.getBindingForCommand(commandId);
    const detail = keyBindings ? keyBinding.keyBindingInnerHTML(keyBindings) : undefined;

    quickView.buttons.push({
        label,
        data: commandId,
        detail
    });
}