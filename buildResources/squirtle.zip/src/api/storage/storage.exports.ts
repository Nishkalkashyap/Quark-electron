import { get, set, update, has, size, isEqual } from 'lodash';
import { throwError } from './../../../throw-error';
import { electron, IBrowserWindow } from '../electron/electron.internal';
import { createFileSystemWatcher } from '../file-watcher/file-watcher.util';
import { Watcher } from '../file-watcher/file-watcher.exports';

abstract class __Store {
    protected _object: any = {};

    public get<T>(key: string, defaultValue?: T): T | undefined {
        return get(this._object, key, defaultValue);
    }

    public set<T>(path: string, value: T): T {
        return set(this._object, path, value);
    }

    public update<T, P>(path: string, updater: (value: T) => P): T {
        return update(this._object, path, updater);
    }

    public has(path: string): boolean {
        return has(this._object, path);
    }

    public delete(path: string): void {
        delete this._object[path];
    }

    public get size(): number {
        return size(this._object);
    }
}

const Store = global.require('electron-store');

export class MemoryStore extends __Store { };

export class PersistantStore extends __Store {

    private _store: (typeof import('electron-store'))['prototype'];
    private _lastWrittenObject: any = {};
    private _watcher: Watcher;
    private _changeHandles: {
        key: string;
        callback: (newValue?: any, oldValue?: any) => void;
    }[] = []

    public get store(): any {
        return this._store.store;
    }

    constructor(options: StoreOptions) {
        super();

        try {
            this._store = new Store(options);
            this._object = this._store.store;

            let filePath: string;
            const isGlobalStore = !options.cwd;
            if (options.cwd) {
                filePath = electron.path.join(options.cwd, options.name + '.' + options.fileExtension);
            } else {
                filePath = electron.path.join(electron.module.remote.app.getPath('userData'), options.name + '.' + options.fileExtension)
            }
            this._watcher = createFileSystemWatcher(filePath);
            this._watcher.on('change', () => {

                if (isGlobalStore) {
                    this._object = this._store.store;
                }
                this._changeHandles.map((val) => {
                    const newValue = get(this._object, val.key);
                    const oldValue = get(this._lastWrittenObject, val.key);
                    if (isEqual(newValue, oldValue)) {
                        return;
                    }

                    try {
                        val.callback(newValue, oldValue);
                    } catch (err) {
                        throwError(err);
                    }

                });
            });

        } catch (err) {
            throwError(err);
            throwError(options);
        }
    }

    public forceUpdate(key?: string): void {
        try {
            if (key && typeof key == 'string') {
                this._store.set(key, this.get(key));
                return;
            }
            this._store.store = this._object;
            this._lastWrittenObject = this._object;
        } catch (err) {
            throwError(err);
        }
    }

    public onDidChange<K extends keyof T, T>(key: string, callback: (newValue: T[K], oldValue: T[K]) => void): void {
        if (typeof key == 'string' && typeof callback == 'function') {
            this._changeHandles.push({ key, callback: callback as any });
            return;
        }

        throwError('Please check your input');
    }
}


interface StoreOptions {
    defaults?: any;
    name?: string;
    cwd?: string;
    fileExtension?: string;
    encryptionKey?: string | Buffer;
}

export namespace storage {

    const isLandingPage = (electron.module.remote.getCurrentWindow() as IBrowserWindow).data.showLandingPage;

    const appPath = electron.path.join(electron.module!.remote.app.getPath('userData'));
    const fileName = (electron.browserWindow.data.project.search('no_file') !== -1 || isLandingPage) ? appPath : electron.browserWindow.data.project;

    const localDirPath = electron.path.join(electron.path.dirname(fileName), '.quark', '.store');
    electron.fs.ensureDirSync(localDirPath);

    const regExp = /\.(build\.qrk|qrk\.asar)$/;

    export const inMemory = new MemoryStore();

    export const local = new PersistantStore({
        cwd: (fileName.match(regExp)) ? localDirPath : electron.path.dirname(fileName),
        // cwd: localDirPath,
        encryptionKey: 'storage.local',
        // name: electron.path.basename(fileName).replace(/(\.build\.qrk)$/, '').replace('.qrk', ''),
        // name: fileName.match(regExp) ? electron.path.basename(fileName).replace('.build.qrk', '.store') : electron.path.basename(fileName).replace('.qrk', ''),
        name: fileName.match(regExp) ? 'store' : electron.path.basename(fileName).replace('.qrk', ''),
        fileExtension: 'qrk'
    });
    export const global = new PersistantStore({
        encryptionKey: 'storage.global',
        name: fileName.match(regExp) ? 'quarkfile.build' : 'quarkfile',
        fileExtension: 'store.qrk'
    });
}