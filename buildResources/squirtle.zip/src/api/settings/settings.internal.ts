import { isEqual, set, cloneDeep } from 'lodash';
import { Keys } from './../../../Keys';
import { SettingScope, Item, Group, Namespace, Iobject, SettingType, son } from './settings.circular';
import { storage } from '../storage/storage.exports';
import { throwError } from './../../../throw-error';
import { IDisposable } from './../../../exports';
export * from './settings.circular';

export namespace settings {

    export function getItemValue(id: string) {
        //just checking if value is an object or primitive
        const value = storage.global.get(Keys.Settings + '.' + id);

        const globalValue = storage.global.get(Keys.Settings + '.' + id);
        const localValue = storage.local.get(Keys.Settings + '.' + id);
        const defaultValue = storage.global.get('default.' + Keys.Settings + '.' + id);

        if (typeof value == 'object') {
            const globalObj = cloneDeep(globalValue || {}) as any;
            const localObj = cloneDeep(localValue || {}) as any;
            const defaultObj = cloneDeep(defaultValue || {}) as any;
            return mergeObject(defaultObj, globalObj, localObj);
        }

        const localHasChanged = !isEqual(defaultValue, localValue);
        const globalHasChanged = !isEqual(defaultValue, globalValue);

        if (localHasChanged) {
            return localValue;
        }

        if (globalHasChanged) {
            return globalValue;
        }

        return defaultValue;
    }


    function mergeObject(defaultObj: object = {}, global: object = {}, local: object = {}) {
        for (let key in defaultObj) {
            if (typeof defaultObj[key] == 'object') {
                mergeObject(defaultObj[key], global[key], local[key]);
            } else {
                const globalHasChanged = !isEqual(global[key], defaultObj[key]);
                const localHasChanged = !isEqual(local[key], defaultObj[key]);
                if (globalHasChanged) {
                    defaultObj[key] = global[key];
                }
                if (localHasChanged) {
                    defaultObj[key] = local[key];
                }
            }
        }

        return defaultObj;
    }



    export function watchSettingItem(id: string, watcher: _Settings.OnDidChangeInterface['handle']): IDisposable {
        let obj = { id: id, handle: watcher };
        _Settings.onDidChangeHandles.push(obj);

        const disposable: IDisposable = {
            dispose: () => {
                const index = _Settings.onDidChangeHandles.findIndex((val) => { return val == obj });
                if (index !== -1) {
                    _Settings.onDidChangeHandles.splice(index, 1);
                }
            }
        }

        return disposable;
    }

    export function addNamespace(namespace: Namespace) {
        if (!Array.isArray(namespace.groups))
            throwError('Is not a valid array');

        const globalNamespace: _Settings.InternalNamespace = JSON.parse(JSON.stringify(namespace));
        globalNamespace.groupIds = [];
        globalNamespace.groups.map((group) => {
            addGroup(group, SettingScope.global);
            globalNamespace.groupIds.push(group.id)
        });
        (_Settings.array.global.push(globalNamespace));

        const localNamespace: _Settings.InternalNamespace = JSON.parse(JSON.stringify(namespace));
        localNamespace.groupIds = [];
        localNamespace.groups.map((group) => {
            addGroup(group, SettingScope.local);
            localNamespace.groupIds.push(group.id)
        });
        (_Settings.array.local.push(localNamespace));

        _Settings.currentNamespace = _Settings.array[_Settings.currentScope][0];

        function addGroup(group: _Settings.InternalGroup, scope: SettingScope) {
            if (!Array.isArray(group.items))
                throwError(`Is not a valid array`);

            group.itemIds = [];
            group.items.map((item) => {
                addItem(item, scope);
                group.itemIds.push(item.id);
            });
        }

        function addItem(item: Item, scope: SettingScope) {

            if (isValidInput(item)) {
                const settingValue = storage[scope].get(Keys.Settings + '.' + item.id, _Settings.getCopy(item[item.type]['value']));
                storage[scope].set(Keys.Settings + '.' + item.id, _Settings.getCopy(settingValue));
                storage[SettingScope.global].set('default.' + Keys.Settings + '.' + item.id, _Settings.getCopy(item[item.type].default));
                const settingItem: Item = _Settings.getCopy(item);
                settingItem[item.type]['value'] = _Settings.getCopy(settingValue);
                Object.assign(item, settingItem);
            } else {
                console.log('not valid input');
            }
        }
    }

    function isValidInput(item: Item): boolean {

        const _isValid = item && item.id && item.name && item.description && item.type && item[item.type]
        if (!_isValid) {
            throwError(`Input is not valid ${item.id + item.name}`);
            return false;
        }

        let isValidInputType: boolean | undefined;
        switch (item.type) {
            case SettingType.INPUT:
                item.input.value = item.input.default;
                isValidInputType =
                    item.input &&
                    isValid(item.input.default);
                break;

            case SettingType.TEXTAREA:
                item.textarea.value = item.textarea.default;
                isValidInputType =
                    item.textarea &&
                    isValid(item.textarea.default);
                break;

            case SettingType.SELECT:
                item.select.value = item.select.default;
                item.select.optionsViewValue ? null : item.select.optionsViewValue = item.select.options;
                isValidInputType =
                    item.select &&
                    isValid(item.select.default) &&
                    isValidSonArray(item.select.options) &&
                    isValidSonArray(item.select.optionsViewValue) &&
                    areEqualArrays(item.select.options, item.select.optionsViewValue);
                break;

            case SettingType.CHECKBOX:
                item.checkbox.value = item.checkbox.default;
                isValidInputType =
                    item.checkbox &&
                    typeof item.checkbox.default == 'boolean';
                break;

            case SettingType.STRING_ARRAY:
                item.stringArray.value ? null : item.stringArray.value = item.stringArray.default.slice();
                isValidInputType =
                    item.stringArray &&
                    areEqualArrays(item.stringArray.value, item.stringArray.default) &&
                    isValidSonArray(item.stringArray.default) &&
                    isValidSonArray(item.stringArray.value);
                break;

            case SettingType.OBJECT:
                item.object.value ? null : item.object.value = JSON.parse(JSON.stringify(item.object.default))
                isValidInputType =
                    item.object &&
                    item.object.default &&
                    Array.isArray(item.object.default) &&
                    item.object.default.every((val) => {
                        return isValid(val.id) && isValid(val.value) && isValid(val.label)
                    });
                break;

            case SettingType.BUTTON:
                isValidInputType =
                    item.button &&
                    typeof item.button.handler == 'function';
                break;
            default:
                throwError('Input is not valid');
        }

        return isValidInputType;


        function isValid(key: son): boolean {
            return typeof key === 'string' || typeof key === 'number';
        }

        function isValidSonArray(keys: son[]): boolean {
            return Array.isArray(keys) && keys.every((val) => { return isValid(val) })
        }

        function areEqualArrays(arr1: son[], arr2: son[]): boolean {
            return arr1.length == arr2.length;
        }
    }
}

export namespace _Settings {

    export let currentScope: SettingScope = SettingScope.global;

    export const array: {
        global: InternalNamespace[],
        local: InternalNamespace[],
    } = {
        global: [],
        local: []
    }

    export const onDidChangeHandles: OnDidChangeInterface[] = []

    export let currentNamespace: InternalNamespace = array[currentScope][0];

    export function updateSettings(item: Item) {
        storage[currentScope].set(Keys.Settings + '.' + item.id, getCopy(item[item.type]['value']));

        const find = onDidChangeHandles.find((val) => {
            return val.id == item.id;
        });

        if (find) {
            find.handle(getCopy(getCopy(item[item.type]['value'])), currentScope);
        }
    }

    export function isChangedInOtherScope(item: Item): boolean {
        const otherScope = currentScope == SettingScope.global ? SettingScope.local : SettingScope.global;
        const value = storage[otherScope].get(Keys.Settings + '.' + item.id);
        const result = !isEqual(item[item.type].default, value);
        return result;
    }

    export function getCopy(item: any) {
        const value = typeof item == 'object' ? JSON.parse(JSON.stringify(item)) : item;
        return value;
    }

    export interface OnDidChangeInterface {
        id: string;
        handle: (value?: any, scope?: SettingScope) => void
    }

    export interface InternalGroup extends Group {
        itemIds: string[];
    }

    export interface InternalNamespace extends Namespace {
        groupIds: string[];
        groups: InternalGroup[];
    }

    export function getObjectFromIobject(_obj: Iobject[]): object {
        let obj = {};
        _obj.map((val) => {
            set(obj, val.id, val.value);
        });
        return obj;
    }
}
