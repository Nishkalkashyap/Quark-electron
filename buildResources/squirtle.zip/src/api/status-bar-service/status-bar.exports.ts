import { IDisposable } from './../../../exports';

export enum StatusBarAlignment {
    Left = 1,
    Right = 2
}

export class StatusBarItem {

    private _text: string;
    public get text() {
        return this._text;
    }
    public set text(text: string) {
        this._text = (typeof text == 'string' || typeof text == 'number') ? text : '';
        this._transformedText = this.textTransform(this._text);
    }

    private _transformedText: string;
    public get transformedText(): string {
        return this._transformedText;
    }
    private textTransform(str: string) {
        return str.replace(/\$\((.+?)\)/g, '<quark-icon icon="$1"></quark-icon>')
    }

    public tooltip: string | undefined;
    public color: string | undefined;
    public backgroundColor: string | undefined;
    public command: string | Function | undefined;

    private _isVisible: boolean = false;
    public get isVisible() {
        return this._isVisible;
    }
    public show() { this._isVisible = true; }
    public hide() { this._isVisible = false; }

    private _isLoading: boolean = false;
    public get isLoading() { return this._isLoading; }
    public showLoading() { this._isLoading = true; }
    public hideLoading() { this._isLoading = false; }

    public dispose: IDisposable['dispose'];

    constructor(public readonly alignment?: StatusBarAlignment, public readonly priority?: number) {
        this.alignment = this.alignment || StatusBarAlignment.Left;
        this.priority = this.priority || 10;
    }
}