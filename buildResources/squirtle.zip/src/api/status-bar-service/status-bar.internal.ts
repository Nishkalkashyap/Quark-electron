import { StatusBarService } from './status-bar.service';

export const statusbar = new StatusBarService();