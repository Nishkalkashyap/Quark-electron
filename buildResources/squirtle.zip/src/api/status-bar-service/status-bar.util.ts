import { StatusBarAlignment, StatusBarItem } from './status-bar.exports';
import { statusbar } from './status-bar.internal';

export function createStatusBarItem(alignment?: StatusBarAlignment, priority?: number): StatusBarItem {
    const item = new StatusBarItem(alignment, priority);
    const disposable = statusbar.registerItem(item);
    item.dispose = disposable.dispose;
    return item;
}