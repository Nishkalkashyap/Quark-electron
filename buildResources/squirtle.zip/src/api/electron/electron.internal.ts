export enum IpcEvents {
    ADD_DEV_MODE_WINDOW = 'ADD_DEV_MODE_WINDOW',
    ADD_RUN_MODE_WINDOW = 'ADD_RUN_MODE_WINDOW',
    HIDE_BUILD_LOADING = 'HIDE_BUILD_LOADING'
}

import { } from 'electron';

export type IBrowserWindow = Electron.BrowserWindow & WindowData

export interface WindowData {
    data: {
        project: string;
        showLandingPage: boolean;
        isDevMode: boolean;
        appPath: string;
        home : string;
    }
}

export namespace electron {

    // var window = global;
    // const isElectron = window && window['process'] && window['process'].type;

    global.require = eval('require');
    const remote: Electron.Remote | undefined = global !== undefined ? global.require('electron').remote : undefined;
    export const module = global !== undefined ? global.require('electron') : null;
    export const mainProcess: NodeJS.Process = remote ? remote.process : null;
    export const fs: typeof import('fs-extra') = global !== undefined ? global.require('fs-extra') : null;
    export const path: typeof import('path') = global !== undefined ? global.require('path') : null;
    export const browserWindow: IBrowserWindow = remote ? remote.getCurrentWindow() as any : null;
}