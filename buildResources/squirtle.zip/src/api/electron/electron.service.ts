import { electron } from './electron.internal';

const win = electron.module!.remote.getCurrentWindow();

export namespace window {

    export function blur(): void {
        win.blur();
    }

    export function center(): void {
        win.center();
    }

    export function close(): void {
        win.close();
    }

    // flashFrame

    export function focus(): void {
        win.focus();
    }

    export function getBounds(): Electron.Rectangle {
        return win.getBounds();
    }

    // getNormalBounds

    export function getOpacity(): number {
        return win.getOpacity();
    }

    export function hide(): void {
        win.hide();
    }

    export function maximize(): void {
        win.maximize();
    }

    export function minimize(): void {
        win.minimize();
    }

    export function reload(): void {
        win.reload();
    }


    export function restore(): void {
        win.restore();
    }

    export function setAlwaysOnTop(): void {
        win.setAlwaysOnTop(true);
    }

    export function setBounds(bounds: Electron.Rectangle, animate?: boolean): void {
        win.setBounds(bounds, animate);
    }

    export function setEnabled(enabled?: boolean): void {
        win.setEnabled(enabled || true);
    }

    // setMinimizable
    // setMinimumSize
    // setMovable


    export function setOpacity(opacity: number): void {
        win.setOpacity(opacity);
    }

    export function setProgressBar(progress: number, mode: ('none' | 'normal' | 'indeterminate' | 'error' | 'paused')): void {
        win.setProgressBar(progress, { mode });
    }

    // setShape
    // setResizable

    export function isResizable(): boolean {
        return win.isResizable();
    }

    export function setResizable(resizable: boolean): void {
        win.setResizable(resizable);
    }

    export function show(): void {
        win.show();
    }

    export function unmaximize(): void {
        win.unmaximize();
    }

    //_______________________________Browser Window API Ends Here

    export function capturePage(callback: (image: Electron.NativeImage) => void): void {
        win.webContents.capturePage(callback)
    }

    export function executeJavaScript(code: string): Promise<any> {
        return win.webContents.executeJavaScript(code, true);
    }

    export function getFrameRate(): number {
        return win.webContents.getFrameRate();
    }

    export function getZoomFactor(): Promise<number> {
        return new Promise((resolve) => {
            win.webContents.getZoomFactor((f) => {
                resolve(f);
            });
        });
    }

    export function getZoomLevel(): Promise<number> {
        return new Promise((resolve) => {
            win.webContents.getZoomLevel((f) => {
                resolve(f);
            });
        });
    }

    export function insertCSS(css: string): void {
        win.webContents.insertCSS(css || '');
    }

    export function setZoomFactor(factor: number): void {
        win.webContents.setZoomFactor(factor || 1);
    }

    export function setZoomLevel(factor: number): void {
        win.webContents.setZoomLevel(factor || 1);
    }

}