import { SnackbarItem, snackbar } from './snackbar.service';

export { snackbar };

export class ISnackbarItem extends SnackbarItem { };

