import { ContextMenuRef } from "../menu-service/menu.exports";
import { SideViewService, BottomViewService, OverlayViewService, TabsViewService } from './view-service.service';
import { Keys } from './../../../Keys';
import { throwError } from './../../../throw-error';

interface BaseController {
    getCurrentView(): views.ViewProvider;
    getAllViews(): views.ViewProvider[];
    isNavbarVisible(): boolean;
    toggleNavbar(): void;
    hideNavbar(): void;
    showNavbar(): void;
    selectNextView(): views.ViewProvider;
    selectPreviousView(): views.ViewProvider;
    triggerUpdate(): void;
    removeView(view: views.ViewProvider): void;
    getViewById(id: string): views.ViewProvider | undefined;
    setView(_view: views.ViewProvider): void;
}

interface VisibilityController {
    isVisible(): boolean;
    toggle(): void;
    hide(): void;
    show(): void;
    maximize(): void;
    minimize(): void;
}

export { SideViewService, BottomViewService, OverlayViewService, TabsViewService };

export const _sideviewController = new SideViewService(Keys.SideViewProvider);
export const _bottomviewController = new BottomViewService(Keys.BottomViewProvider);
export const _tabsviewController = new TabsViewService(Keys.TabsViewProvider);
export const _overlayviewController = new OverlayViewService(Keys.OverlayViewProvider, 'app-overlay-provider-container');

export namespace views {

    export interface SideviewController extends BaseController, VisibilityController { };
    export interface BottomviewController extends BaseController, VisibilityController { };
    export interface OverlayviewController extends BaseController, VisibilityController { };
    export interface TabsviewController extends BaseController { };

    export interface ButtonField {
        label: string;
        handle: () => void;
        icon?: string;
    }

    interface _SelectField {
        placeholder: string;
        currentValue: string;
        isHidden: boolean;
        handle: (option?: string) => void;
        options: string[];
        viewOptions: string[];
    }

    export type SelectField = Partial<_SelectField>
    export type InputField = Partial<_InputField>

    interface _InputField {
        placeholder: string;
        currentValue: string;
        isHidden: boolean;
        handle: (value?: string) => void;
    }

    export class ViewProvider {

        public dispose: () => void;//todo

        private _isVisible = false;
        public isVisible(): boolean { return this._isVisible; }
        //todo---hiding if current view
        public hide: () => void;
        public show(): void { this._isVisible = true; }

        public isFocused: () => boolean;//todo
        public focus: () => void;//todo
        public blur: () => void//todo

        private _id: string = (Math.random() + Date.now()).toString();
        public getId(): string { return this._id; }
        public setId: (id: string) => void;//todo

        public actionIconClickHandle: () => void;//todo

        private _progressBarValue: number | 'indeterminate' = 0;
        public getProgressBarValue(): number | 'indeterminate' {
            return this._progressBarValue;
        }
        public setProgressBar(val?: number): void {
            if (val) {
                this._progressBarValue = val;
            } else {
                this._progressBarValue = 'indeterminate';
            }
        }
        public hideProgressBar(): void {
            this._progressBarValue = 0;
        }

        public onWillCreateElement: () => void;
        public onDidCreateElement: () => void;
        public onDidConnectElement: () => void;
        public onWillRemoveElement: () => void;
        public onDidRemoveElement: () => void;

        public onCanEnterView: () => Promise<boolean> | boolean;
        public onDidEnterView: () => void;
        public onCanRemoveView: () => Promise<boolean> | boolean;
        public onDidRemoveView: () => void;

        constructor(public label: string, public element: HTMLElement, public readonly keepConnected?: boolean, id?: string) {
            if (id) {
                this._id = id;
            }
        }


        public busy: boolean = false;
        public badge: string | number;
        public icon: string;
        public tooltip: string;
        public data: any;
        public actionIcon: string;
        public contextMenu: ContextMenuRef;
        public buttons: ButtonField[];
        public inputField: InputField;
        public selectField: SelectField;
    }

    export const sideviewController = getController<SideviewController>(_sideviewController as any, 'side');
    export const bottomviewController = getController<BottomviewController>(_bottomviewController as any, 'bottom');
    export const tabsviewController = getController<TabsviewController>(_tabsviewController as any, 'tabs');
    export const overlayviewController = getController<OverlayviewController>(_overlayviewController as any, 'overlay');

    export function createSideView(label: string, element?: HTMLElement, keepConnected?: boolean, id?: string): ViewProvider {
        if (idExistsInController(_sideviewController as any, id)) {
            throwError('View with provided id already exists');
            return;
        }

        const provider = new ViewProvider(label, element || document.createElement('div'), keepConnected, id);
        const disposable = _sideviewController.registerView(provider);

        provider.dispose = disposable.dispose;
        registerHandles(_sideviewController, provider);
        return provider;
    }

    export function createBottomView(label: string, element?: HTMLElement, keepConnected?: boolean, id?: string): ViewProvider {
        if (idExistsInController(_bottomviewController as any, id)) {
            throwError('View with provided id already exists');
            return;
        }

        const provider = new ViewProvider(label, element || document.createElement('div'), keepConnected, id);
        const disposable = _bottomviewController.registerView(provider);

        // provider.actionIcon = ('mat:close');
        // provider.actionIcon = ('ionicon:md-arrow-dropright');
        provider.dispose = disposable.dispose;
        registerHandles(_bottomviewController, provider);
        return provider;
    }

    export function createTabsView(label: string, element?: HTMLElement, keepConnected?: boolean, id?: string): ViewProvider {
        if (idExistsInController(_tabsviewController as any, id)) {
            throwError('View with provided id already exists');
            return;
        }

        const provider = new ViewProvider(label, element || document.createElement('div'), keepConnected, id);
        const disposable = _tabsviewController.registerView(provider);

        provider.actionIcon = ('mat:close');
        provider.dispose = disposable.dispose;
        registerHandles(_tabsviewController as any, provider);
        return provider;
    }
}

function getController<T>(_controller: SideViewService & OverlayViewService, type: 'side' | 'bottom' | 'tabs' | 'overlay'): T {

    const baseController: BaseController = {
        getAllViews: _controller.getAllViews.bind(_controller),
        getCurrentView: _controller.getCurrentView.bind(_controller),
        getViewById: _controller.getViewById.bind(_controller),
        hideNavbar: _controller.hideNavbar.bind(_controller),
        isNavbarVisible: _controller.isNavbarVisible.bind(_controller),
        removeView: _controller.removeView.bind(_controller),
        selectNextView: _controller.selectNextView.bind(_controller),
        selectPreviousView: _controller.selectPreviousView.bind(_controller),
        setView: _controller.setView.bind(_controller),
        showNavbar: _controller.showNavbar.bind(_controller),
        toggleNavbar: _controller.toggleNavbar.bind(_controller),
        triggerUpdate: _controller.triggerUpdate.bind(_controller)
    }

    let extendedController: VisibilityController;
    //VisibilityController
    if (type == 'bottom' || type == 'side') {
        extendedController = {
            hide: _controller.hide.bind(_controller),
            isVisible: _controller.isVisible.bind(_controller),
            show: _controller.show.bind(_controller),
            toggle: _controller.toggle.bind(_controller),
            maximize: null,
            minimize: null
        }
    }

    return Object.assign({}, baseController, extendedController || {}) as any;
}

function registerHandles(controller: SideViewService, view: views.ViewProvider) {
    view.isFocused = () => controller.getCurrentView() == view;
    view.focus = () => {
        view.show();
        controller.setView(view);
    };

    view.hide = () => {
        (view as any)._isVisible = false;
        if (controller.getAllViews().length > 1) {
            controller.selectPreviousView();
        } else {
            controller.setView(null);
        }
    }

    view.setId = (id) => {
        const find = controller.getAllViews().find((view) => {
            return view.getId() == id;
        });
        if (find) {
            throwError('View with provided id already exists');
            return;
        }
        (view as any)._id = id;
    }
    view.actionIconClickHandle = () => controller.removeView(view);
}

function idExistsInController(controller: SideViewService, id: string): boolean {
    const find = controller.getAllViews().find((v) => { return v.getId() == id });
    return !!find;
}