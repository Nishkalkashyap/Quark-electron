import { handles } from './window.handles.internal';
import { default as Vue } from 'vue';
import wrap from '@vue/web-component-wrapper';
import esmVue from 'vue/dist/vue.esm.js';
export { textToWorker } from 'text-to-worker';
// import p5 from 'p5';

export function registerOnQuitHandle(func: Function) {
    if (func && typeof func == 'function') {
        handles.push(func);
    }
}

export function createElementFromHtml(html: string): HTMLElement {
    const ele = document.createElement('quark-element-creator');
    ele.setAttribute('html', html);
    ele['html'] = html.trim();
    return ele;
}

export function createVueWebComponent(name: string, data: Vue.ComponentOptions<any>, createElement: boolean): undefined | HTMLElement {

    if (!window.customElements.get(name)) {
        window.customElements.define(name, wrap(esmVue, data));
    }

    if (createElement) {
        return document.createElement(name);
    }
}

// export function createSketch(node: HTMLElement, sketch: (instance: p5, ...args: any[]) => any, sync?: boolean) {
//     const p = new p5(sketch, node, sync);
//     return p;
// }